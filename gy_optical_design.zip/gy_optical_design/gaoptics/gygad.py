import numpy
import random
import cloudpickle
import time
import warnings
import concurrent.futures
import inspect
import logging
from gaoptics import utils_ga
from gaoptics import helper
from gaoptics import visualize
import sys
import torch
import math


class GA(utils_ga.parent_selection.ParentSelection, utils_ga.crossover.Crossover, utils_ga.mutation.Mutation,
         helper.unique.Unique, visualize.plot.Plot):
    supported_int_types = [int, numpy.int8, numpy.int16, numpy.int32, numpy.int64,
                           numpy.uint, numpy.uint8, numpy.uint16, numpy.uint32, numpy.uint64,
                           torch.int8, torch.int16, torch.int32, torch.int64,
                           torch.uint8]
    supported_float_types = [float, torch.Tensor, numpy.float16, numpy.float32, numpy.float64,
                             torch.float32, torch.float16, torch.float64]
    supported_int_float_types = supported_int_types + supported_float_types

    def __init__(self,
                 num_generations,
                 num_parents_mating,
                 fitness_func1,
                 fitness_func0=None,
                 fitness_batch_size=None,
                 initial_population=None,
                 sol_per_pop=None,
                 num_genes=None,
                 init_range_low=-4,
                 init_range_high=4,
                 gene_type=torch.float32,
                 parent_selection_type="sss",
                 keep_parents=-1,
                 keep_elitism=5,
                 K_tournament=3,
                 crossover_type="single_point",
                 crossover_probability=None,
                 mutation_type="random",
                 mutation_probability=None,
                 mutation_by_replacement=False,
                 mutation_percent_genes='default',
                 mutation_num_genes=None,
                 random_mutation_min_val=0,
                 random_mutation_max_val=1.0,
                 gene_space=None,
                 allow_duplicate_genes=True,
                 on_start=None,
                 on_fitness=None,
                 on_parents=None,
                 on_crossover=None,
                 on_mutation=None,
                 on_generation=None,
                 on_stop=None,
                 delay_after_gen=0.0,
                 save_best_solutions=False,
                 save_solutions=False,
                 suppress_warnings=False,
                 stop_criteria=None,
                 random_seed=None,
                 logger=None,
                 len_pop=None,
                 last_generation_parents_indices=None):
        """
        GA类的构造函数接受创建GA类实例所需的所有参数，参数如下：

        num_generations: 遗传代数。
        num_parents_mating: 在 mating pool 选择为亲本的数量

        fitness_func: 接受函数/方法并返回解决方案的适应度值。在PyGAD 2.20.0中，传递了第三个引用“PyGAD.GA”实例的参数。
                      如果方法，则它必须接受4个参数，其中第四个参数指的是该方法的对象。
        fitness_batch_size: 添加在PyGAD 2.19.0中。支持批量计算适应度。如果值为1或None，则会为每个无形解决方案调用适应度函数。
                            如果给定另一个值X，其中X既不是1也不是None（例如X＝3），则对每个X（3）个解调用一次适应度函数。

        initial_population: 用户定义的初始种群。当用户想要使用自定义初始种群开始生成时，它非常有用。它默认为None，这意味着用户没有指定初始种群。
                            在这种情况下，PyGAD使用“sol_per_pop”和“num_genes”参数创建初始种群。如果“initial_population”为None，
                            而两个参数（“sol_per_pop”或“num_genes”）中的任何一个也为None时，将引发异常。
        sol_per_pop: 种群解数量
        num_genes: 方程中的参数量

        init_range_low: 从中选择初始群体中的基因值的随机范围的较低值。默认值为-4。提供PyGAD 1.0.20及更高版本。
        init_range_high: 从中选择初始群体中的基因值的随机范围的较低值。默认值为4。提供PyGAD 1.0.20及更高版本。
        # 可以将两个参数中的任何一个（“init_range_low”和“init_range_high”）的值设置为等于、高于或低于另一个参数（即init_range_low不需要低于init_range_high）。

        gene_type: 基因的类型。它被指定为这些类型中的任何一个 (int, float, numpy.int8, numpy.int16, numpy.int32, numpy.int64,
                   numpy.uint, numpy.uint8, numpy.uint16, numpy.uint32, numpy.uint64,
                   numpy.float16, numpy.float32, numpy.float64)

        parent_selection_type: 父代选择的种类
        keep_parents: 如果为0，则表示当前群体中没有亲本将在下一个群体中使用。
                      如果为-1，这意味着当前种群中的所有父母都将在下一个种群中使用。
                      如果设置为值>0，则指定的值指的是当前群体中要在下一个群体中使用的亲本数量。
                      一些父代选择算子，如秩选择，有利于种群多样性，因此将父母留在下一代可能是有益的。
                      然而，其他一些亲本选择算子，如轮盘选择（RWS），具有更高的选择压力，在下一代中保留多个亲本可能会严重损害种群多样性。
                      只有当keep_elitism参数为0时，此参数才会生效。
        K_tournament: 当“parent_selection_type”的值为“tournament”时，“K_tournament”参数指定从中随机选择父项的解决方案的数量。

        keep_elitism: 在PyGAD 2.18.0中添加。它可以取值0或满足（0<=keep_elitism<=sol_per_pop）的正整数。
                      它默认为1，这意味着只有当前一代中的最佳解决方案才会保留在下一代中。如果指定为0，则表示它无效。
                      如果分配一个正整数K，那么最好的K个解将保留在下一代中。不能为其分配大于分配给sol_per_pop参数的值的值。
                      如果此参数的值不为0，则keep_presents参数将不起作用。

        crossover_type: 杂交operator的类型。如果crossover_type=None，则跳过杂交步骤，这意味着不应用杂交，因此不会在下一代中创建子代。下一代将在当前种群中使用这些解决方案。
        crossover_probability: 为杂交操作选择解的概率。如果解的概率<=交叉概率，则选择该解。该值必须介于0和1之间（包括0和1）。

        mutation_type: 突变operator的类型。如果mutation_type=None，则绕过突变步骤，这意味着不应用突变，因此不将任何突变应用于使用杂交操作创建的后代。后代在下一代中的使用将保持不变。
        mutation_probability: 为突变操作选择基因的概率。如果基因概率<=突变概率，则选择该基因。它接受固定突变的单个值，或者接受自适应突变的2个值的列表/tuple/numpy.ndarray。
                              值必须介于0和1之间（包括0和1）。如果指定，则不需要2个参数mutation_percent_genes和mutation_num_genes。

        mutation_by_replacement: 一个可选的布尔参数。只有当选定的突变类型是随机的（mutation_type=“随机”）时，它才起作用。
                                 在这种情况下，设置mutation_by_replacement=True意味着用随机生成的值替换基因。
                                 如果为False，则它没有效果，随机突变通过将随机值添加到基因中来起作用。

        mutation_percent_genes: 突变基因的百分比，默认为字符串“default”，即10%。如果存在2个参数mutation_probability或mutation_num_genes中的任何一个，
                                则该参数没有作用。
        mutation_num_genes: 要突变的基因数，默认为“无”。如果参数mutation_num_genes存在，则不需要参数mutation_percent_genes。
                            如果突变概率参数存在，则该参数不起作用。
        random_mutation_min_val: 从中选择一个随机值添加到所选基因突变的范围的最小值。默认值为-1.0。
        random_mutation_max_val: 从中选择一个随机值添加到所选基因突变的范围的最大值。默认值为1.0。

        gene_space: 它接受基因所有可能值的列表。此列表用于突变步骤。仅当基因空间是一组离散值时才应使用。
                    如果参数gene_space存在，则不需要两个参数（random_mutation_min_val和random_mutation_max_val）。
                    在PyGAD 2.5.0中添加。在PyGAD 2.11.0中，可以为gene_space分配一个dict。

        on_start:在遗传算法开始进化之前，只接受一次调用的函数/方法。
                 如果是函数，则它必须接受表示遗传算法实例的单个参数。如果是方法，则它必须接受2个参数，其中第二个参数指的是该方法的对象。
                 在PyGAD 2.6.0中添加。
        n_fitness:在计算总体中所有解的适合度值后，接受要调用的函数/方法。如果函数，则它必须接受两个参数：1）所有解的适应度值的列表2）遗传算法的实例。
                  如果方法，则它必须接受3个参数，其中第三个参数指的是该方法的对象。在PyGAD 2.6.0中添加。
        on_parents:在选择配对的父对象后，接受要调用的函数/方法。如果是函数，那么它必须接受两个参数：第一个代表遗传算法的实例，第二个代表所选的父代。
                   如果方法，则它必须接受3个参数，其中第三个参数指的是该方法的对象。在PyGAD 2.6.0中添加。
        on_crossover:接受每次应用杂交操作时要调用的函数/方法。如果函数，则它必须接受两个参数：第一个参数表示遗传算法的实例，第二个参数表示使用交叉生成的后代。
                     如果方法，则它必须接受3个参数，其中第三个参数指的是该方法的对象。在PyGAD 2.6.0中添加。
        on_mutation:接受每次应用变异操作时要调用的函数/方法。如果是函数，那么它必须接受两个参数：第一个代表遗传算法的实例，第二个代表应用突变后的后代。
                    如果方法，则它必须接受3个参数，其中第三个参数指的是该方法的对象。在PyGAD 2.6.0中添加。
        on_generation:接受每次生成后要调用的函数/方法。如果函数，则它必须接受表示遗传算法实例的单个参数。如果函数返回“stop”，
                      那么run（）方法将在不完成其他生成的情况下停止。如果是方法，则它必须接受2个参数，其中第二个参数指的是该方法的对象。在PyGAD 2.6.0中添加。
        on_stop:在遗传算法停止之前或完成所有生成时，只接受一次调用的函数/方法。如果函数，那么它必须接受两个参数：第一个参数代表遗传算法的实例，第二个参数是最后一个群体解的适应度值列表。
                如果方法，则它必须接受3个参数，其中第三个参数指的是该方法的对象。在PyGAD 2.6.0中添加。

        delay_after_gen: 在PyGAD 2.4.0中添加。它接受一个非负数，指定在生成完成后到下一代之前等待的秒数。它默认为0.0，这意味着生成后没有延迟。

        save_best_solutions: 添加在PyGAD 2.9.0中，其类型为bool。如果为True，则每一代中的最佳解决方案都会保存到“best_solutions”属性中。
                             请谨慎使用此参数，因为当代数或基因数较大时，它可能会导致内存溢出。
        save_solutions：在PyGAD 2.15.0中添加，其类型为bool。如果为True，则每一代中的所有解决方案都将保存到“solutions”属性中。
                        请谨慎使用此参数，因为当种群中的代数、基因数或解决方案数较大时，它可能会导致内存溢出。

        suppress_warnings: 在PyGAD 2.10.0中添加，其类型为布尔。如果为True，则不会显示任何警告消息。默认为False。

        allow_duplicate_genes: 在PyGAD 2.13.0中添加。如果为True，则解决方案/染色体可能具有重复的基因值。
                               如果为False，则每个基因在其解决方案中都将具有唯一的值。

        stop_criteria: 添加在PyGAD 2.15.0中。如果至少有一个标准成立，它被分配给一些标准来停止进化。


        random_seed: 在PyGAD 2.18.0中添加。它定义了随机函数生成器要使用的随机种子（我们在NumPy和随机模块中使用随机函数）。
                     这有助于通过设置相同的随机种子来重现相同的结果。

        logger: 添加在PyGAD 2.20.0中。它接受“logging.logger”类的记录器对象来记录消息。
                如果没有传递任何记录器，则会创建一个默认记录器，以将消息记录/打印到控制台，就像使用“print（）”函数一样。
        """
        self.op_n = False
        try:
            self.last_generation_parents_indices = last_generation_parents_indices
            self.len_pop = len_pop
            self.device = len_pop.simulation.device
            # 如果没有传递任何记录器，则创建一个只将消息记录到控制台的记录器。
            if logger is None:
                # 创建一个使用模块名称命名的记录器。
                logger = logging.getLogger(__name__)
                # 将记录器日志级别设置为“DEBUG”，以记录各种消息。
                logger.setLevel(logging.DEBUG)

                # 从以前的运行中清除任何附加到记录器的处理程序。
                # 如果未清除处理程序，则新的处理程序将附加到处理程序列表中。
                # 这使得单个日志消息根据处理程序列表的长度进行重复。
                logger.handlers.clear()

                # 创建handler（处理程序）
                stream_handler = logging.StreamHandler()
                # 将处理程序日志级别设置为“DEBUG”，以记录从记录器接收到的所有类型的消息。
                stream_handler.setLevel(logging.DEBUG)

                # 创建只包含日志消息的格式化程序。
                formatter = logging.Formatter('%(message)s')

                # 将格式化程序添加到处理程序中。
                stream_handler.setFormatter(formatter)

                # 将处理程序添加到记录器。
                logger.addHandler(stream_handler)
            else:
                # Validate that the passed logger is of type 'logging.Logger'.
                if isinstance(logger, logging.Logger):
                    pass
                else:
                    raise TypeError(
                        f"The expected type of the 'logger' parameter is 'logging.Logger' but {type(logger)} found.")

            # 创建“self.logger”属性以保存记录器。
            # 不要使用“print（）”，而是使用“self.logger.info（）”
            self.logger = logger
            self.random_seed = random_seed
            if random_seed is None:
                pass
            else:
                torch.cuda.manual_seed(random_seed)
                random.seed(random_seed)

            # 如果suppress_warnings为bool且其值为False，则打印警告消息。
            self.suppress_warnings = suppress_warnings
            self.mutation_by_replacement = mutation_by_replacement
            self.allow_duplicate_genes = allow_duplicate_genes

            # Validate gene_space
            self.gene_space_nested = False
            self.gene_space = gene_space

            # Validate init_range_low and init_range_high
            self.init_range_low = init_range_low
            self.init_range_high = init_range_high

            # Validate gene_type
            self.gene_type = [gene_type, None]
            self.gene_type_single = True

            # Call the unpack_gene_space() method in the pygad.helper.unique.Unique class.
            self.gene_space_unpacked = self.unpack_gene_space(range_min=self.init_range_low,
                                                              range_max=self.init_range_high)
            self.initial_population = initial_population
            self.population = self.initial_population
            # Number of genes in the solution.
            self.num_genes = self.initial_population.shape[1]
            # Number of solutions in the population.
            self.sol_per_pop = self.initial_population.shape[0]
            # The population size.
            self.pop_size = (self.sol_per_pop, self.num_genes)

            # Round initial_population and population
            self.initial_population = self.round_genes(self.initial_population)
            self.population = self.round_genes(self.population)

            self.random_mutation_min_val = random_mutation_min_val
            self.random_mutation_max_val = random_mutation_max_val

            self.num_parents_mating = num_parents_mating
            self.crossover = crossover_type
            crossover_type = crossover_type.lower()  # 大写变为小写

            if crossover_type == "single_point":
                self.crossover = self.single_point_crossover
            elif crossover_type == "two_points":
                self.crossover = self.two_points_crossover
            elif crossover_type == "two_points":
                self.crossover = self.two_points_crossover
            elif crossover_type == "uniform":
                self.crossover = self.uniform_crossover
            elif crossover_type == "scattered":
                self.crossover = self.scattered_crossover
            else:
                self.valid_parameters = False
                raise TypeError(
                    f"Undefined crossover type. \nThe assigned value to the crossover_type ({crossover_type}) "
                    f"parameter does not refer to one of the supported crossover types which are: \n-single_point ("
                    f"for single point crossover)\n-two_points (for two points crossover)\n-uniform (for uniform "
                    f"crossover)\n-scattered (for scattered crossover).\n")

            self.crossover_type = crossover_type

            # Calculate the value of crossover_probability
            if crossover_probability is None:
                self.crossover_probability = None
            elif type(crossover_probability) in GA.supported_int_float_types:
                if 0 <= crossover_probability <= 1:
                    self.crossover_probability = crossover_probability
                else:
                    self.valid_parameters = False
                    raise ValueError(
                        f"The value assigned to the 'crossover_probability' parameter must be between 0 and 1 "
                        f"inclusive but ({crossover_probability}) found.")
            else:
                self.valid_parameters = False
                raise TypeError(
                    f"Unexpected type for the 'crossover_probability' parameter. Float is expected but ({crossover_probability}) of type {type(crossover_probability)} found.")

            # mutation: Refers to the method that applies the mutation operator based on the selected type of
            # mutation in the mutation_type property. Validating the mutation type: mutation_type "adaptive" mutation
            # is supported starting from PyGAD 2.10.0
            if mutation_type is None:
                self.mutation = None
            elif inspect.ismethod(mutation_type):
                # Check if the mutation_type is a method that accepts 3 paramater.
                if mutation_type.__code__.co_argcount == 3:
                    # The mutation method assigned to the mutation_type parameter is validated.
                    self.mutation = mutation_type
                else:
                    self.valid_parameters = False
                    raise ValueError(
                        f"When 'mutation_type' is assigned to a method, then it must accept 3 parameters:\n1) "
                        f"Expected to be the 'self' object.\n2) The offspring to be mutated.\n3) The instance from "
                        f"the pygad.GA class.\n\nThe passed mutation method named '{mutation_type.__code__.co_name}' "
                        f"accepts {mutation_type.__code__.co_argcount} parameter(s).")
            elif callable(mutation_type):
                # Check if the mutation_type is a function that accepts 2 paramater.
                if mutation_type.__code__.co_argcount == 2:
                    # The mutation function assigned to the mutation_type parameter is validated.
                    self.mutation = mutation_type
                else:
                    self.valid_parameters = False
                    raise ValueError(
                        f"When 'mutation_type' is assigned to a function, then this mutation function must accept 2 "
                        f"parameters:\n1) The offspring to be mutated.\n2) The instance from the pygad.GA class to "
                        f"retrieve any property like population, gene data type, gene space, etc.\n\nThe passed "
                        f"mutation function named '{mutation_type.__code__.co_name}' accepts "
                        f"{mutation_type.__code__.co_argcount} parameter(s).")
            elif not (type(mutation_type) is str):
                self.valid_parameters = False
                raise TypeError(
                    f"The expected type of the 'mutation_type' parameter is either callable or str but {type(mutation_type)} found.")
            else:  # type mutation_type is str
                mutation_type = mutation_type.lower()
                if mutation_type == "random":
                    self.mutation = self.random_mutation
                elif mutation_type == "swap":
                    self.mutation = self.swap_mutation
                elif mutation_type == "scramble":
                    self.mutation = self.scramble_mutation
                elif mutation_type == "inversion":
                    self.mutation = self.inversion_mutation
                elif mutation_type == "adaptive":
                    self.mutation = self.adaptive_mutation
                else:
                    self.valid_parameters = False
                    raise TypeError(
                        f"Undefined mutation type. \nThe assigned string value to the 'mutation_type' parameter ({mutation_type}) does not refer to one of the supported mutation types which are: \n-random (for random mutation)\n-swap (for swap mutation)\n-inversion (for inversion mutation)\n-scramble (for scramble mutation)\n-adaptive (for adaptive mutation).\n")

            self.mutation_type = mutation_type

            # Calculate the value of mutation_probability
            if not (self.mutation_type is None):
                if mutation_probability is None:
                    self.mutation_probability = None
                elif (mutation_type != "adaptive"):
                    # Mutation probability is fixed not adaptive.
                    if type(mutation_probability) in GA.supported_int_float_types:
                        if mutation_probability >= 0 and mutation_probability <= 1:
                            self.mutation_probability = mutation_probability
                        else:
                            self.valid_parameters = False
                            raise ValueError(
                                f"The value assigned to the 'mutation_probability' parameter must be between 0 and 1 inclusive but ({mutation_probability}) found.")
                    else:
                        self.valid_parameters = False
                        raise TypeError(
                            f"Unexpected type for the 'mutation_probability' parameter. A numeric value is expected but ({mutation_probability}) of type {type(mutation_probability)} found.")
                else:
                    # Mutation probability is adaptive not fixed.
                    if type(mutation_probability) in [list, tuple, numpy.ndarray]:
                        if len(mutation_probability) == 2:
                            for el in mutation_probability:
                                if type(el) in GA.supported_int_float_types:
                                    if el >= 0 and el <= 1:
                                        pass
                                    else:
                                        self.valid_parameters = False
                                        raise ValueError(
                                            f"The values assigned to the 'mutation_probability' parameter must be between 0 and 1 inclusive but ({el}) found.")
                                else:
                                    self.valid_parameters = False
                                    raise TypeError(
                                        f"Unexpected type for a value assigned to the 'mutation_probability' parameter. A numeric value is expected but ({el}) of type {type(el)} found.")
                            if mutation_probability[0] < mutation_probability[1]:
                                if not self.suppress_warnings:
                                    warnings.warn(
                                        f"The first element in the 'mutation_probability' parameter is {mutation_probability[0]} which is smaller than the second element {mutation_probability[1]}. This means the mutation rate for the high-quality solutions is higher than the mutation rate of the low-quality ones. This causes high disruption in the high qualitiy solutions while making little changes in the low quality solutions. Please make the first element higher than the second element.")
                            self.mutation_probability = mutation_probability
                        else:
                            self.valid_parameters = False
                            raise ValueError(
                                f"When mutation_type='adaptive', then the 'mutation_probability' parameter must have only 2 elements but ({len(mutation_probability)}) element(s) found.")
                    else:
                        self.valid_parameters = False
                        raise TypeError(
                            f"Unexpected type for the 'mutation_probability' parameter. When mutation_type='adaptive', then list/tuple/numpy.ndarray is expected but ({mutation_probability}) of type {type(mutation_probability)} found.")
            else:
                pass

            # Calculate the value of mutation_num_genes
            if not (self.mutation_type is None):
                if mutation_num_genes is None:
                    # The mutation_num_genes parameter does not exist. Checking whether adaptive mutation is used.
                    if (mutation_type != "adaptive"):
                        # The percent of genes to mutate is fixed not adaptive.
                        if mutation_percent_genes == 'default'.lower():
                            mutation_percent_genes = 10
                            # Based on the mutation percentage in the 'mutation_percent_genes' parameter, the number of genes to mutate is calculated.
                            mutation_num_genes = numpy.uint32(
                                (mutation_percent_genes * self.num_genes) / 100)
                            # Based on the mutation percentage of genes, if the number of selected genes for mutation is less than the least possible value which is 1, then the number will be set to 1.
                            if mutation_num_genes == 0:
                                if self.mutation_probability is None:
                                    if not self.suppress_warnings:
                                        warnings.warn(
                                            f"The percentage of genes to mutate (mutation_percent_genes={mutation_percent_genes}) resutled in selecting ({mutation_num_genes}) genes. The number of genes to mutate is set to 1 (mutation_num_genes=1).\nIf you do not want to mutate any gene, please set mutation_type=None.")
                                mutation_num_genes = 1

                        elif type(mutation_percent_genes) in GA.supported_int_float_types:
                            if (mutation_percent_genes <= 0 or mutation_percent_genes > 100):
                                self.valid_parameters = False
                                raise ValueError(
                                    f"The percentage of selected genes for mutation (mutation_percent_genes) must be > 0 and <= 100 but ({mutation_percent_genes}) found.\n")
                            else:
                                # If mutation_percent_genes equals the string "default", then it is replaced by the numeric value 10.
                                if mutation_percent_genes == 'default'.lower():
                                    mutation_percent_genes = 10

                                # Based on the mutation percentage in the 'mutation_percent_genes' parameter, the number of genes to mutate is calculated.
                                mutation_num_genes = numpy.uint32(
                                    (mutation_percent_genes * self.num_genes) / 100)
                                # Based on the mutation percentage of genes, if the number of selected genes for mutation is less than the least possible value which is 1, then the number will be set to 1.
                                if mutation_num_genes == 0:
                                    if self.mutation_probability is None:
                                        if not self.suppress_warnings:
                                            warnings.warn(
                                                f"The percentage of genes to mutate (mutation_percent_genes={mutation_percent_genes}) resutled in selecting ({mutation_num_genes}) genes. The number of genes to mutate is set to 1 (mutation_num_genes=1).\nIf you do not want to mutate any gene, please set mutation_type=None.")
                                    mutation_num_genes = 1
                        else:
                            self.valid_parameters = False
                            raise TypeError(
                                f"Unexpected value or type of the 'mutation_percent_genes' parameter. It only accepts the string 'default' or a numeric value but ({mutation_percent_genes}) of type {type(mutation_percent_genes)} found.")
                    else:
                        # The percent of genes to mutate is adaptive not fixed.
                        if type(mutation_percent_genes) in [list, tuple, numpy.ndarray]:
                            if len(mutation_percent_genes) == 2:
                                mutation_num_genes = numpy.zeros_like(
                                    mutation_percent_genes, dtype=numpy.uint32)
                                for idx, el in enumerate(mutation_percent_genes):
                                    if type(el) in GA.supported_int_float_types:
                                        if (el <= 0 or el > 100):
                                            self.valid_parameters = False
                                            raise ValueError(
                                                f"The values assigned to the 'mutation_percent_genes' must be > 0 and <= 100 but ({mutation_percent_genes}) found.\n")
                                    else:
                                        self.valid_parameters = False
                                        raise TypeError(
                                            f"Unexpected type for a value assigned to the 'mutation_percent_genes' parameter. An integer value is expected but ({el}) of type {type(el)} found.")
                                    # At this point of the loop, the current value assigned to the parameter 'mutation_percent_genes' is validated.
                                    # Based on the mutation percentage in the 'mutation_percent_genes' parameter, the number of genes to mutate is calculated.
                                    mutation_num_genes[idx] = numpy.uint32(
                                        (mutation_percent_genes[idx] * self.num_genes) / 100)
                                    # Based on the mutation percentage of genes, if the number of selected genes for mutation is less than the least possible value which is 1, then the number will be set to 1.
                                    if mutation_num_genes[idx] == 0:
                                        if not self.suppress_warnings:
                                            warnings.warn(
                                                f"The percentage of genes to mutate ({mutation_percent_genes[idx]}) resutled in selecting ({mutation_num_genes[idx]}) genes. The number of genes to mutate is set to 1 (mutation_num_genes=1).\nIf you do not want to mutate any gene, please set mutation_type=None.")
                                        mutation_num_genes[idx] = 1
                                if mutation_percent_genes[0] < mutation_percent_genes[1]:
                                    if not self.suppress_warnings:
                                        warnings.warn(
                                            f"The first element in the 'mutation_percent_genes' parameter is ({mutation_percent_genes[0]}) which is smaller than the second element ({mutation_percent_genes[1]}).\nThis means the mutation rate for the high-quality solutions is higher than the mutation rate of the low-quality ones. This causes high disruption in the high qualitiy solutions while making little changes in the low quality solutions.\nPlease make the first element higher than the second element.")
                                # At this point outside the loop, all values of the parameter 'mutation_percent_genes' are validated. Eveyrthing is OK.
                            else:
                                self.valid_parameters = False
                                raise ValueError(
                                    f"When mutation_type='adaptive', then the 'mutation_percent_genes' parameter must have only 2 elements but ({len(mutation_percent_genes)}) element(s) found.")
                        else:
                            if self.mutation_probability is None:
                                self.valid_parameters = False
                                raise TypeError(
                                    f"Unexpected type of the 'mutation_percent_genes' parameter. When mutation_type='adaptive', then the 'mutation_percent_genes' parameter should exist and assigned a list/tuple/numpy.ndarray with 2 values but ({mutation_percent_genes}) found.")
                # The mutation_num_genes parameter exists. Checking whether adaptive mutation is used.
                elif (mutation_type != "adaptive"):
                    # Number of genes to mutate is fixed not adaptive.
                    if type(mutation_num_genes) in GA.supported_int_types:
                        if (mutation_num_genes <= 0):
                            self.valid_parameters = False
                            raise ValueError(
                                f"The number of selected genes for mutation (mutation_num_genes) cannot be <= 0 but ({mutation_num_genes}) found. If you do not want to use mutation, please set mutation_type=None\n")
                        elif (mutation_num_genes > self.num_genes):
                            self.valid_parameters = False
                            raise ValueError(
                                f"The number of selected genes for mutation (mutation_num_genes), which is ({mutation_num_genes}), cannot be greater than the number of genes ({self.num_genes}).\n")
                    else:
                        self.valid_parameters = False
                        raise TypeError(
                            f"The 'mutation_num_genes' parameter is expected to be a positive integer but the value ({mutation_num_genes}) of type {type(mutation_num_genes)} found.\n")
                else:
                    # Number of genes to mutate is adaptive not fixed.
                    if type(mutation_num_genes) in [list, tuple, numpy.ndarray]:
                        if len(mutation_num_genes) == 2:
                            for el in mutation_num_genes:
                                if type(el) in GA.supported_int_types:
                                    if el <= 0:
                                        self.valid_parameters = False
                                        raise ValueError(
                                            f"The values assigned to the 'mutation_num_genes' cannot be <= 0 but ({el}) found. If you do not want to use mutation, please set mutation_type=None\n")
                                    elif el > self.num_genes:
                                        self.valid_parameters = False
                                        raise ValueError(
                                            f"The values assigned to the 'mutation_num_genes' cannot be greater than the number of genes ({self.num_genes}) but ({el}) found.\n")
                                else:
                                    self.valid_parameters = False
                                    raise TypeError(
                                        f"Unexpected type for a value assigned to the 'mutation_num_genes' parameter. "
                                        f"An integer value is expected but ({el}) of type {type(el)} found.")
                                # At this point of the loop, the current value assigned to the parameter
                                # 'mutation_num_genes' is validated.
                            if mutation_num_genes[0] < mutation_num_genes[1]:
                                if not self.suppress_warnings:
                                    warnings.warn(
                                        f"The first element in the 'mutation_num_genes' parameter is {mutation_num_genes[0]} which is smaller than the second element {mutation_num_genes[1]}. This means the mutation rate for the high-quality solutions is higher than the mutation rate of the low-quality ones. This causes high disruption in the high qualitiy solutions while making little changes in the low quality solutions. Please make the first element higher than the second element.")
                            # At this point outside the loop, all values of the parameter 'mutation_num_genes' are validated. Eveyrthing is OK.
                        else:
                            self.valid_parameters = False
                            raise ValueError(
                                f"When mutation_type='adaptive', then the 'mutation_num_genes' parameter must have only 2 elements but ({len(mutation_num_genes)}) element(s) found.")
                    else:
                        self.valid_parameters = False
                        raise TypeError(
                            f"Unexpected type for the 'mutation_num_genes' parameter. When mutation_type='adaptive', "
                            f"then list/tuple/numpy.ndarray is expected but ({mutation_num_genes}) of type "
                            f"{type(mutation_num_genes)} found.")
            else:
                pass

            # Validating mutation_by_replacement and mutation_type
            if self.mutation_type != "random" and self.mutation_by_replacement:
                if not self.suppress_warnings:
                    warnings.warn(
                        f"The mutation_by_replacement parameter is set to True while the mutation_type parameter is "
                        f"not set to random but ({mutation_type}). Note that the mutation_by_replacement parameter "
                        f"has an effect only when mutation_type='random'.")

            # Check if crossover and mutation are both disabled.
            if (self.mutation_type is None) and (self.crossover_type is None):
                if not self.suppress_warnings:
                    warnings.warn(
                        "The 2 parameters mutation_type and crossover_type are None. This disables any type of "
                        "evolution the genetic algorithm can make. As a result, the genetic algorithm cannot find a "
                        "better solution that the best solution in the initial population.")

            # select_parents: Refers to a method that selects the parents based on the parent selection type
            # specified in the parent_selection_type attribute. Validating the selected type of parent selection:
            # parent_selection_type
            if inspect.ismethod(parent_selection_type):
                # Check if the parent_selection_type is a method that accepts 4 paramaters.
                if parent_selection_type.__code__.co_argcount == 4:
                    # population: Added in PyGAD 2.16.0. It should used only to support custom parent selection
                    # functions. Otherwise, it should be left to None to retirve the population by self.population.
                    # The parent selection method assigned to the parent_selection_type parameter is validated.
                    self.select_parents = parent_selection_type
                else:
                    self.valid_parameters = False
                    raise ValueError(
                        f"When 'parent_selection_type' is assigned to a method, then it must accept 4 parameters:\n1) "
                        f"Expected to be the 'self' object.\n2) The fitness values of the current population.\n3) The "
                        f"number of parents needed.\n4) The instance from the pygad.GA class.\n\nThe passed parent "
                        f"selection method named '{parent_selection_type.__code__.co_name}' accepts "
                        f"{parent_selection_type.__code__.co_argcount} parameter(s).")
            elif callable(parent_selection_type):
                # Check if the parent_selection_type is a function that accepts 3 paramaters.
                if parent_selection_type.__code__.co_argcount == 3:
                    # population: Added in PyGAD 2.16.0. It should used only to support custom parent selection
                    # functions. Otherwise, it should be left to None to retirve the population by self.population.
                    # The parent selection function assigned to the parent_selection_type parameter is validated.
                    self.select_parents = parent_selection_type
                else:
                    self.valid_parameters = False
                    raise ValueError(
                        f"When 'parent_selection_type' is assigned to a user-defined function, then this parent "
                        f"selection function must accept 3 parameters:\n1) The fitness values of the current "
                        f"population.\n2) The number of parents needed.\n3) The instance from the pygad.GA class to "
                        f"retrieve any property like population, gene data type, gene space, etc.\n\nThe passed "
                        f"parent selection function named '{parent_selection_type.__code__.co_name}' accepts "
                        f"{parent_selection_type.__code__.co_argcount} parameter(s).")
            elif not (type(parent_selection_type) is str):
                self.valid_parameters = False

                raise TypeError(
                    f"The expected type of the 'parent_selection_type' parameter is either callable or str but {type(parent_selection_type)} found.")
            else:
                parent_selection_type = parent_selection_type.lower()
                if parent_selection_type == "sss":
                    self.select_parents = self.steady_state_selection
                elif parent_selection_type == "div":
                    self.select_parents = self.divide_selection
                elif parent_selection_type == "rws":
                    self.select_parents = self.roulette_wheel_selection
                elif parent_selection_type == "sus":
                    self.select_parents = self.stochastic_universal_selection
                elif parent_selection_type == "random":
                    self.select_parents = self.random_selection
                elif parent_selection_type == "tournament":
                    self.select_parents = self.tournament_selection
                elif parent_selection_type == "rank":
                    self.select_parents = self.rank_selection
                else:
                    self.valid_parameters = False
                    raise TypeError(
                        f"Undefined parent selection type: {parent_selection_type}. \nThe assigned value to the "
                        f"'parent_selection_type' parameter does not refer to one of the supported parent selection "
                        f"techniques which are: \n-sss (for steady state selection)\n-rws (for roulette wheel "
                        f"selection)\n-sus (for stochastic universal selection)\n-rank (for rank selection)\n-random "
                        f"(for random selection)\n-tournament (for tournament selection).\n")

            # For tournament selection, validate the K value.
            if parent_selection_type == "tournament":
                if K_tournament > self.sol_per_pop:
                    K_tournament = self.sol_per_pop
                    if not self.suppress_warnings:
                        warnings.warn(
                            f"K of the tournament selection ({K_tournament}) should not be greater than the number of solutions within the population ({self.sol_per_pop}).\nK will be clipped to be equal to the number of solutions in the population (sol_per_pop).\n")
                elif K_tournament <= 0:
                    self.valid_parameters = False
                    raise ValueError(f"K of the tournament selection cannot be <=0 but ({K_tournament}) found.\n")

            self.K_tournament = K_tournament

            # Validating the number of parents to keep in the next population: keep_parents
            if not (type(keep_parents) in GA.supported_int_types):
                self.valid_parameters = False
                raise TypeError(
                    f"Incorrect type of the value assigned to the keep_parents parameter. The value ({keep_parents}) of type {type(keep_parents)} found but an integer is expected.")
            elif keep_parents > self.sol_per_pop or keep_parents > self.num_parents_mating or keep_parents < -1:
                self.valid_parameters = False
                raise ValueError(
                    f"Incorrect value to the keep_parents parameter: {keep_parents}. \nThe assigned value to the "
                    f"keep_parent parameter must satisfy the following conditions: \n1) Less than or equal to "
                    f"sol_per_pop\n2) Less than or equal to num_parents_mating\n3) Greater than or equal to -1.")

            self.keep_parents = keep_parents

            if parent_selection_type == "sss" and self.keep_parents == 0:
                if not self.suppress_warnings:
                    warnings.warn(
                        "The steady-state parent (sss) selection operator is used despite that no parents are kept in "
                        "the next generation.")

            # Validating the number of elitism to keep in the next population: keep_elitism
            if not (type(keep_elitism) in GA.supported_int_types):
                self.valid_parameters = False
                raise TypeError(
                    f"Incorrect type of the value assigned to the keep_elitism parameter. The value ({keep_elitism}) of type {type(keep_elitism)} found but an integer is expected.")
            elif keep_elitism > self.sol_per_pop or keep_elitism < 0:
                self.valid_parameters = False
                raise ValueError(
                    f"Incorrect value to the keep_elitism parameter: {keep_elitism}. \nThe assigned value to the "
                    f"keep_elitism parameter must satisfy the following conditions: \n1) Less than or equal to "
                    f"sol_per_pop\n2) Greater than or equal to 0.")

            self.keep_elitism = keep_elitism

            # Validate keep_parents.
            if self.keep_elitism == 0:
                # Keep all parents in the next population.
                if self.keep_parents == -1:
                    self.num_offspring = self.sol_per_pop - self.num_parents_mating
                # Keep no parents in the next population.
                elif self.keep_parents == 0:
                    self.num_offspring = self.sol_per_pop
                # Keep the specified number of parents in the next population.
                elif self.keep_parents > 0:
                    self.num_offspring = self.sol_per_pop - self.keep_parents
            else:
                self.num_offspring = self.sol_per_pop - self.keep_elitism

            # 检查fitness_func是否是一个方法。在PyGAD 2.19.0中，可以将一个方法传递给适应度函数。
            # 如果函数被传递，那么它接受2个参数。如果方法，则它接受3个参数。
            # 在PyGAD#2.20.0中，传递了一个新参数，该参数引用了“PyGAD.GA”类的实例。因此，函数接受3个参数，方法接受4个参数。
            self.fitness_func1 = fitness_func1
            self.fitness_func0 = fitness_func0
            self.select_func_flag = 1


            if fitness_batch_size is None:
                pass
            elif not (type(fitness_batch_size) in GA.supported_int_types):
                self.valid_parameters = False
                raise TypeError(
                    f"The value assigned to the fitness_batch_size parameter is expected to be integer but the value ({fitness_batch_size}) of type {type(fitness_batch_size)} found.")
            elif fitness_batch_size <= 0 or fitness_batch_size > self.sol_per_pop:
                self.valid_parameters = False
                raise ValueError(
                    f"The value assigned to the fitness_batch_size parameter must be:\n1) Greater than 0.\n2) Less "
                    f"than or equal to sol_per_pop ({self.sol_per_pop}).\nBut the value ({fitness_batch_size}) found.")

            self.fitness_batch_size = fitness_batch_size

            # Check if the on_start exists.
            if not (on_start is None):
                if inspect.ismethod(on_start):
                    # Check if the on_start method accepts 2 paramaters.
                    if on_start.__code__.co_argcount == 2:
                        self.on_start = on_start
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The method assigned to the on_start parameter must accept only 2 parameters:\n1) "
                            f"Expected to be the 'self' object.\n2) The instance of the genetic algorithm.\nThe "
                            f"passed method named '{on_start.__code__.co_name}' accepts "
                            f"{on_start.__code__.co_argcount} parameter(s).")
                # Check if the on_start is a function.
                elif callable(on_start):
                    # Check if the on_start function accepts only a single paramater.
                    if on_start.__code__.co_argcount == 1:
                        self.on_start = on_start
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The function assigned to the on_start parameter must accept only 1 parameter "
                            f"representing the instance of the genetic algorithm.\nThe passed function named '"
                            f"{on_start.__code__.co_name}' accepts {on_start.__code__.co_argcount} parameter(s).")
                else:
                    self.valid_parameters = False

                    raise TypeError(
                        f"The value assigned to the on_start parameter is expected to be of type function but {type(on_start)} found.")
            else:
                self.on_start = None

            # Check if the on_fitness exists.
            if not (on_fitness is None):
                # Check if the on_fitness is a method.
                if inspect.ismethod(on_fitness):
                    # Check if the on_fitness method accepts 3 paramaters.
                    if on_fitness.__code__.co_argcount == 3:
                        self.on_fitness = on_fitness
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The method assigned to the on_fitness parameter must accept 3 parameters:\n1) Expected "
                            f"to be the 'self' object.\n2) The instance of the genetic algorithm.3) The fitness "
                            f"values of all solutions.\nThe passed method named '{on_fitness.__code__.co_name}' "
                            f"accepts {on_fitness.__code__.co_argcount} parameter(s).")
                # Check if the on_fitness is a function.
                elif callable(on_fitness):
                    # Check if the on_fitness function accepts 2 paramaters.
                    if on_fitness.__code__.co_argcount == 2:
                        self.on_fitness = on_fitness
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The function assigned to the on_fitness parameter must accept 2 parameters representing the instance of the genetic algorithm and the fitness values of all solutions.\nThe passed function named '{on_fitness.__code__.co_name}' accepts {on_fitness.__code__.co_argcount} parameter(s).")
                else:
                    self.valid_parameters = False
                    raise TypeError(
                        f"The value assigned to the on_fitness parameter is expected to be of type function but {type(on_fitness)} found.")
            else:
                self.on_fitness = None

            # Check if the on_parents exists.
            if not (on_parents is None):
                # Check if the on_parents is a method.
                if inspect.ismethod(on_parents):
                    # Check if the on_parents method accepts 3 paramaters.
                    if on_parents.__code__.co_argcount == 3:
                        self.on_parents = on_parents
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The method assigned to the on_parents parameter must accept 3 parameters:\n1) Expected "
                            f"to be the 'self' object.\n2) The instance of the genetic algorithm.\n3) The fitness "
                            f"values of all solutions.\nThe passed method named '{on_parents.__code__.co_name}' "
                            f"accepts {on_parents.__code__.co_argcount} parameter(s).")
                # Check if the on_parents is a function.
                elif callable(on_parents):
                    # Check if the on_parents function accepts 2 paramaters.
                    if on_parents.__code__.co_argcount == 2:
                        self.on_parents = on_parents
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The function assigned to the on_parents parameter must accept 2 parameters representing "
                            f"the instance of the genetic algorithm and the fitness values of all solutions.\nThe "
                            f"passed function named '{on_parents.__code__.co_name}' accepts "
                            f"{on_parents.__code__.co_argcount} parameter(s).")
                else:
                    self.valid_parameters = False
                    raise TypeError(
                        f"The value assigned to the on_parents parameter is expected to be of type function but {type(on_parents)} found.")
            else:
                self.on_parents = None

            # Check if the on_crossover exists.
            if not (on_crossover is None):
                # Check if the on_crossover is a method.
                if inspect.ismethod(on_crossover):
                    # Check if the on_crossover method accepts 3 paramaters.
                    if on_crossover.__code__.co_argcount == 3:
                        self.on_crossover = on_crossover
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The method assigned to the on_crossover parameter must accept 3 parameters:\n1) "
                            f"Expected to be the 'self' object.\n2) The instance of the genetic algorithm.\n2) The "
                            f"offspring generated using crossover.\nThe passed method named '"
                            f"{on_crossover.__code__.co_name}' accepts {on_crossover.__code__.co_argcount} parameter("
                            f"s).")
                # Check if the on_crossover is a function.
                elif callable(on_crossover):
                    # Check if the on_crossover function accepts 2 paramaters.
                    if on_crossover.__code__.co_argcount == 2:
                        self.on_crossover = on_crossover
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The function assigned to the on_crossover parameter must accept 2 parameters "
                            f"representing the instance of the genetic algorithm and the offspring generated using "
                            f"crossover.\nThe passed function named '{on_crossover.__code__.co_name}' accepts "
                            f"{on_crossover.__code__.co_argcount} parameter(s).")
                else:
                    self.valid_parameters = False
                    raise TypeError(
                        f"The value assigned to the on_crossover parameter is expected to be of type function but {type(on_crossover)} found.")
            else:
                self.on_crossover = None

            # Check if the on_mutation exists.
            if not (on_mutation is None):
                # Check if the on_mutation is a method.
                if inspect.ismethod(on_mutation):
                    # Check if the on_mutation method accepts 3 paramaters.
                    if on_mutation.__code__.co_argcount == 3:
                        self.on_mutation = on_mutation
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The method assigned to the on_mutation parameter must accept 3 parameters:\n1) Expected "
                            f"to be the 'self' object.\n2) The instance of the genetic algorithm.\n2) The offspring "
                            f"after applying the mutation operation.\nThe passed method named '"
                            f"{on_mutation.__code__.co_name}' accepts {on_mutation.__code__.co_argcount} parameter(s).")
                # Check if the on_mutation is a function.
                elif callable(on_mutation):
                    # Check if the on_mutation function accepts 2 paramaters.
                    if on_mutation.__code__.co_argcount == 2:
                        self.on_mutation = on_mutation
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The function assigned to the on_mutation parameter must accept 2 parameters "
                            f"representing the instance of the genetic algorithm and the offspring after applying the "
                            f"mutation operation.\nThe passed function named '{on_mutation.__code__.co_name}' accepts "
                            f"{on_mutation.__code__.co_argcount} parameter(s).")
                else:
                    self.valid_parameters = False
                    raise TypeError(
                        f"The value assigned to the on_mutation parameter is expected to be of type function but {type(on_mutation)} found.")
            else:
                self.on_mutation = None

            # Check if the on_generation exists.
            if not (on_generation is None):
                # Check if the on_generation is a method.
                if inspect.ismethod(on_generation):
                    # Check if the on_generation method accepts 2 paramaters.
                    if (on_generation.__code__.co_argcount == 2):
                        self.on_generation = on_generation
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The method assigned to the on_generation parameter must accept 2 parameters:\n1) "
                            f"Expected to be the 'self' object.\n2) The instance of the genetic algorithm.\nThe "
                            f"passed method named '{on_generation.__code__.co_name}' accepts "
                            f"{on_generation.__code__.co_argcount} parameter(s).")
                # Check if the on_generation is a function.
                elif callable(on_generation):
                    # Check if the on_generation function accepts only a single paramater.
                    if on_generation.__code__.co_argcount == 1:
                        self.on_generation = on_generation
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The function assigned to the on_generation parameter must accept only 1 parameter "
                            f"representing the instance of the genetic algorithm.\nThe passed function named '"
                            f"{on_generation.__code__.co_name}' accepts {on_generation.__code__.co_argcount} "
                            f"parameter(s).")
                else:
                    self.valid_parameters = False
                    raise TypeError(
                        f"The value assigned to the on_generation parameter is expected to be of type function but {type(on_generation)} found.")
            else:
                self.on_generation = None

            # Check if the on_stop exists.
            if not (on_stop is None):
                # Check if the on_stop is a method.
                if inspect.ismethod(on_stop):
                    # Check if the on_stop method accepts 3 paramaters.
                    if on_stop.__code__.co_argcount == 3:
                        self.on_stop = on_stop
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The method assigned to the on_stop parameter must accept 3 parameters:\n1) Expected to "
                            f"be the 'self' object.\n2) The instance of the genetic algorithm.\n2) A list of the "
                            f"fitness values of the solutions in the last population.\nThe passed method named '"
                            f"{on_stop.__code__.co_name}' accepts {on_stop.__code__.co_argcount} parameter(s).")
                # Check if the on_stop is a function.
                elif callable(on_stop):
                    # Check if the on_stop function accepts 2 paramaters.
                    if on_stop.__code__.co_argcount == 2:
                        self.on_stop = on_stop
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The function assigned to the on_stop parameter must accept 2 parameters representing "
                            f"the instance of the genetic algorithm and a list of the fitness values of the solutions "
                            f"in the last population.\nThe passed function named '{on_stop.__code__.co_name}' accepts "
                            f"{on_stop.__code__.co_argcount} parameter(s).")
                else:
                    self.valid_parameters = False
                    raise TypeError(
                        f"The value assigned to the 'on_stop' parameter is expected to be of type function but {type(on_stop)} found.")
            else:
                self.on_stop = None

            # Validate delay_after_gen
            if type(delay_after_gen) in GA.supported_int_float_types:
                if delay_after_gen >= 0.0:
                    self.delay_after_gen = delay_after_gen
                else:
                    self.valid_parameters = False
                    raise ValueError(
                        f"The value passed to the 'delay_after_gen' parameter must be a non-negative number. The value passed is ({delay_after_gen}) of type {type(delay_after_gen)}.")
            else:
                self.valid_parameters = False
                raise TypeError(
                    f"The value passed to the 'delay_after_gen' parameter must be of type int or float but {type(delay_after_gen)} found.")

            # Validate save_best_solutions
            if type(save_best_solutions) is bool:
                if save_best_solutions:
                    if not self.suppress_warnings:
                        warnings.warn(
                            "Use the 'save_best_solutions' parameter with caution as it may cause memory overflow "
                            "when either the number of generations or number of genes is large.")
            else:
                self.valid_parameters = False
                raise TypeError(
                    f"The value passed to the 'save_best_solutions' parameter must be of type bool but {type(save_best_solutions)} found.")

            # Validate save_solutions
            if type(save_solutions) is bool:
                if save_solutions:
                    if not self.suppress_warnings:
                        warnings.warn(
                            "Use the 'save_solutions' parameter with caution as it may cause memory overflow when "
                            "either the number of generations, number of genes, or number of solutions in population "
                            "is large.")
            else:
                self.valid_parameters = False
                raise TypeError(
                    f"The value passed to the 'save_solutions' parameter must be of type bool but {type(save_solutions)} found.")

            self.stop_criteria = []
            self.supported_stop_words = ["reach", "saturate"]
            if stop_criteria is None:
                # None: Stop after passing through all generations.
                self.stop_criteria = None
            elif type(stop_criteria) is str:
                # reach_{target_fitness}: Stop if the target fitness value is reached. saturate_{num_generations}:
                # Stop if the fitness value does not change (saturates) for the given number of generations.
                criterion = stop_criteria.split("_")
                if len(criterion) == 2:
                    stop_word = criterion[0]
                    number = criterion[1]

                    if stop_word in self.supported_stop_words:
                        pass
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"In the 'stop_criteria' parameter, the supported stop words are '{self.supported_stop_words}' but '{stop_word}' found.")

                    if number.replace(".", "").isnumeric():
                        number = float(number)
                    else:
                        self.valid_parameters = False
                        raise ValueError(
                            f"The value following the stop word in the 'stop_criteria' parameter must be a number but the value ({number}) of type {type(number)} found.")

                    self.stop_criteria.append([stop_word, number])

                else:
                    self.valid_parameters = False
                    raise ValueError(
                        f"For format of a single criterion in the 'stop_criteria' parameter is 'word_number' but '{stop_criteria}' found.")

            elif type(stop_criteria) in [list, tuple, numpy.ndarray]:
                # Remove duplicate criterira by converting the list to a set then back to a list.
                stop_criteria = list(set(stop_criteria))
                for idx, val in enumerate(stop_criteria):
                    if type(val) is str:
                        criterion = val.split("_")
                        if len(criterion) == 2:
                            stop_word = criterion[0]
                            number = criterion[1]

                            if stop_word in self.supported_stop_words:
                                pass
                            else:
                                self.valid_parameters = False
                                raise ValueError(
                                    f"In the 'stop_criteria' parameter, the supported stop words are {self.supported_stop_words} but '{stop_word}' found.")

                            if number.replace(".", "").isnumeric():
                                number = float(number)
                            else:
                                self.valid_parameters = False
                                raise ValueError(
                                    f"The value following the stop word in the 'stop_criteria' parameter must be a number but the value ({number}) of type {type(number)} found.")

                            self.stop_criteria.append([stop_word, number])

                        else:
                            self.valid_parameters = False
                            raise ValueError(
                                f"The format of a single criterion in the 'stop_criteria' parameter is 'word_number' but {criterion} found.")
                    else:
                        self.valid_parameters = False
                        raise TypeError(
                            f"When the 'stop_criteria' parameter is assigned a tuple/list/numpy.ndarray, then its elements must be strings but the value ({val}) of type {type(val)} found at index {idx}.")
            else:
                self.valid_parameters = False
                raise TypeError(
                    f"The expected value of the 'stop_criteria' is a single string or a list/tuple/numpy.ndarray of strings but the value ({stop_criteria}) of type {type(stop_criteria)} found.")

            # Set the `run_completed` property to False. It is set to `True` only after the `run()` method is complete.
            self.run_completed = False

            # The number of completed generations.
            self.generations_completed = 0

            # 此时，所有必要的参数验证都已成功完成，我们确信参数是有效的。当GA类构造函数中传递的所有参数都有效时，请设置为True。
            self.valid_parameters = True

            # 遗传算法的参数
            self.num_generations = abs(num_generations)
            self.parent_selection_type = parent_selection_type

            # 突变参数
            self.mutation_percent_genes = mutation_percent_genes
            self.mutation_num_genes = mutation_num_genes

            # 即使在类头中声明了这样的参数，也会将其分配给此处的对象，以便在保存对象后访问它。
            # 包含每一代最佳解决方案的适合度值的列表。
            self.best_solutions_fitness = []

            # 达到最佳适应度值的世代数。只有在“run（）”方法完成后，才会为其分配生成编号。否则，其值为-1。
            self.best_solution_generation = -1

            self.save_best_solutions = save_best_solutions
            self.best_solutions = []  # 为每一代种群提供最佳解决方案。

            self.save_solutions = save_solutions
            self.solutions = []  # Holds the solutions in each generation.
            # Holds the fitness of the solutions in each generation.
            self.solutions_fitness = []

            # 上一代适应度
            self.last_generation_fitness = None
            # 上一代父本
            self.last_generation_parents = None
            # 上一代杂交后代
            self.last_generation_offspring_crossover = None
            # 上一代变异后代
            self.last_generation_offspring_mutation = None
            # 保存在last_generation_formation属性中的适应度值之前的一代适应度值。添加在PyGAD 2.16.2中。
            self.previous_generation_fitness = None
            # 在PyGAD 2.18.0中添加。NumPy数组，根据'keep_elitism'参数中传递的值保存当前一代的精英。只有当“keep_elitism”参数具有非零值时，它才有效。
            self.last_generation_elitism = None
            # 添加在PyGAD 2.19.0中。NumPy数组，保存当前一代精英主义的索引。只有当“keep_elitism”参数具有非零值时，它才有效。
            self.last_generation_elitism_indices = None
        except Exception as e:
            self.logger.exception(e)
            sys.exit(-1)

    def round_genes(self, solutions):
        for gene_idx in range(self.num_genes):
            if self.gene_type_single:
                if not self.gene_type[1] is None:
                    solutions[:, gene_idx] = numpy.round(solutions[:, gene_idx],
                                                         self.gene_type[1])
            else:
                if not self.gene_type[gene_idx][1] is None:
                    solutions[:, gene_idx] = numpy.round(numpy.asarray(solutions[:, gene_idx],
                                                                       dtype=self.gene_type[gene_idx][0]),
                                                         self.gene_type[gene_idx][1])
        return solutions

    def initialize_population(self,
                              low,
                              high,
                              allow_duplicate_genes,
                              mutation_by_replacement,
                              gene_type):
        """
        将初始种群随机创建为NumPy数组。数组保存在名为“population”的实例属性中。
        low：从中选择初始群体中基因值的随机范围的较低值。默认值为-4。提供PyGAD 1.0.20及更高版本。
        high：从中选择初始群体中的基因值的随机范围的上限。默认值为4。可在PyGAD 1.0.20中获得。
        此方法指定以下3个实例属性的值：1。pop_size：人口规模。
                                 2.population：最初，保持初始种群，然后在每一代之后更新。
                                 3.init_population：保留初始种群。
        """

        # 种群数量 = (染色体数量，每条染色体的基因数量)
        # 群体将具有sol_per_pop个染色体，其中每个染色体都具有num_genes个基因。
        self.pop_size = (self.sol_per_pop, self.num_genes)
        if self.gene_space is None:
            # Creating the initial population randomly.
            if self.gene_type_single:
                self.population = numpy.asarray(numpy.random.uniform(low=low,
                                                                     high=high,
                                                                     size=self.pop_size),
                                                dtype=self.gene_type[
                                                    0])  # A NumPy array holding the initial population.
            else:
                # Create an empty population of dtype=object to support storing mixed data types within the same array.
                self.population = numpy.zeros(
                    shape=self.pop_size, dtype=object)
                # Loop through the genes, randomly generate the values of a single gene across the entire population, and add the values of each gene to the population.
                for gene_idx in range(self.num_genes):

                    if type(self.init_range_low) in self.supported_int_float_types:
                        range_min = self.init_range_low
                        range_max = self.init_range_high
                    else:
                        range_min = self.init_range_low[gene_idx]
                        range_max = self.init_range_high[gene_idx]

                    # A vector of all values of this single gene across all solutions in the population.
                    gene_values = numpy.asarray(numpy.random.uniform(low=range_min,
                                                                     high=range_max,
                                                                     size=self.pop_size[0]),
                                                dtype=self.gene_type[gene_idx][0])
                    # Adding the current gene values to the population.
                    self.population[:, gene_idx] = gene_values

            if allow_duplicate_genes == False:
                for solution_idx in range(self.population.shape[0]):
                    # self.logger.info("Before", self.population[solution_idx])
                    self.population[solution_idx], _, _ = self.solve_duplicate_genes_randomly(
                        solution=self.population[solution_idx],
                        min_val=low,
                        max_val=high,
                        mutation_by_replacement=True,
                        gene_type=gene_type,
                        num_trials=10)
                    # self.logger.info("After", self.population[solution_idx])

        elif self.gene_space_nested:
            if self.gene_type_single == True:
                # Reaching this block means:
                # 1) gene_space is nested (gene_space_nested is True).
                # 2) gene_type is not nested (gene_type_single is True).
                self.population = numpy.zeros(shape=self.pop_size,
                                              dtype=self.gene_type[0])
                for sol_idx in range(self.sol_per_pop):
                    for gene_idx in range(self.num_genes):

                        if type(self.init_range_low) in self.supported_int_float_types:
                            range_min = self.init_range_low
                            range_max = self.init_range_high
                        else:
                            range_min = self.init_range_low[gene_idx]
                            range_max = self.init_range_high[gene_idx]

                        if self.gene_space[gene_idx] is None:

                            # The following commented code replace the None value with a single number that will not change again.
                            # This means the gene value will be the same across all solutions.
                            # self.gene_space[gene_idx] = numpy.asarray(numpy.random.uniform(low=low,
                            #                high=high,
                            #                size=1), dtype=self.gene_type[0])[0]
                            # self.population[sol_idx, gene_idx] = list(self.gene_space[gene_idx]).copy()

                            # The above problem is solved by keeping the None value in the gene_space parameter. This forces PyGAD to generate this value for each solution.
                            self.population[sol_idx, gene_idx] = numpy.asarray(numpy.random.uniform(low=range_min,
                                                                                                    high=range_max,
                                                                                                    size=1),
                                                                               dtype=self.gene_type[0])[0]
                        elif type(self.gene_space[gene_idx]) in [numpy.ndarray, list, tuple, range]:
                            # Check if the gene space has None values. If any, then replace it with randomly generated values according to the 3 attributes init_range_low, init_range_high, and gene_type.
                            if type(self.gene_space[gene_idx]) is range:
                                temp_gene_space = self.gene_space[gene_idx]
                            else:
                                # Convert to list because tuple and range do not have copy().
                                # We copy the gene_space to a temp variable to keep its original value.
                                # In the next for loop, the gene_space is changed.
                                # Later, the gene_space is restored to its original value using the temp variable.
                                temp_gene_space = list(
                                    self.gene_space[gene_idx]).copy()

                            for idx, val in enumerate(self.gene_space[gene_idx]):
                                if val is None:
                                    self.gene_space[gene_idx][idx] = numpy.asarray(numpy.random.uniform(low=range_min,
                                                                                                        high=range_max,
                                                                                                        size=1),
                                                                                   dtype=self.gene_type[0])[0]
                            # Find the difference between the current gene space and the current values in the solution.
                            unique_gene_values = list(set(self.gene_space[gene_idx]).difference(
                                set(self.population[sol_idx, :gene_idx])))
                            if len(unique_gene_values) > 0:
                                self.population[sol_idx, gene_idx] = random.choice(unique_gene_values)
                            else:
                                # If there is no unique values, then we have to select a duplicate value.
                                self.population[sol_idx, gene_idx] = random.choice(
                                    self.gene_space[gene_idx])

                            self.population[sol_idx, gene_idx] = self.gene_type[0](self.population[sol_idx, gene_idx])

                            # Restore the gene_space from the temp_gene_space variable.
                            self.gene_space[gene_idx] = list(
                                temp_gene_space).copy()
                        elif type(self.gene_space[gene_idx]) is dict:
                            if 'step' in self.gene_space[gene_idx].keys():
                                self.population[sol_idx, gene_idx] = \
                                    numpy.asarray(
                                        numpy.random.choice(numpy.arange(start=self.gene_space[gene_idx]['low'],
                                                                         stop=self.gene_space[gene_idx]['high'],
                                                                         step=self.gene_space[gene_idx]['step']),
                                                            size=1),
                                        dtype=self.gene_type[0])[0]
                            else:
                                self.population[sol_idx, gene_idx] = \
                                    numpy.asarray(numpy.random.uniform(low=self.gene_space[gene_idx]['low'],
                                                                       high=self.gene_space[gene_idx]['high'],
                                                                       size=1),
                                                  dtype=self.gene_type[0])[0]
                        elif type(self.gene_space[gene_idx]) in GA.supported_int_float_types:
                            self.population[sol_idx, gene_idx] = self.gene_space[gene_idx]
                        else:
                            # There is no more options.
                            pass
            else:
                # Reaching this block means:
                # 1) gene_space is nested (gene_space_nested is True).
                # 2) gene_type is nested (gene_type_single is False).
                self.population = numpy.zeros(shape=self.pop_size,
                                              dtype=object)
                for sol_idx in range(self.sol_per_pop):
                    for gene_idx in range(self.num_genes):

                        if type(self.init_range_low) in self.supported_int_float_types:
                            range_min = self.init_range_low
                            range_max = self.init_range_high
                        else:
                            range_min = self.init_range_low[gene_idx]
                            range_max = self.init_range_high[gene_idx]

                        if type(self.gene_space[gene_idx]) in [numpy.ndarray, list, tuple, range]:
                            # Convert to list because tuple and range do not have copy().
                            # We copy the gene_space to a temp variable to keep its original value.
                            # In the next for loop, the gene_space is changed.
                            # Later, the gene_space is restored to its original value using the temp variable.
                            temp_gene_space = list(self.gene_space[gene_idx]).copy()

                            # Check if the gene space has None values. If any, then replace it with randomly generated values according to the 3 attributes init_range_low, init_range_high, and gene_type.
                            for idx, val in enumerate(self.gene_space[gene_idx]):
                                if val is None:
                                    self.gene_space[gene_idx][idx] = numpy.asarray(numpy.random.uniform(low=range_min,
                                                                                                        high=range_max,
                                                                                                        size=1),
                                                                                   dtype=self.gene_type[gene_idx][0])[0]

                            self.population[sol_idx, gene_idx] = random.choice(self.gene_space[gene_idx])
                            self.population[sol_idx, gene_idx] = self.gene_type[gene_idx][0](
                                self.population[sol_idx, gene_idx])
                            # Restore the gene_space from the temp_gene_space variable.
                            self.gene_space[gene_idx] = temp_gene_space.copy()
                        elif type(self.gene_space[gene_idx]) is dict:
                            if 'step' in self.gene_space[gene_idx].keys():
                                self.population[sol_idx, gene_idx] = \
                                    numpy.asarray(
                                        numpy.random.choice(numpy.arange(start=self.gene_space[gene_idx]['low'],
                                                                         stop=self.gene_space[gene_idx]['high'],
                                                                         step=self.gene_space[gene_idx]['step']),
                                                            size=1),
                                        dtype=self.gene_type[gene_idx][0])[0]
                            else:
                                self.population[sol_idx, gene_idx] = \
                                    numpy.asarray(numpy.random.uniform(low=self.gene_space[gene_idx]['low'],
                                                                       high=self.gene_space[gene_idx]['high'],
                                                                       size=1),
                                                  dtype=self.gene_type[gene_idx][0])[0]
                        elif type(self.gene_space[gene_idx]) == type(None):
                            temp_gene_value = numpy.asarray(numpy.random.uniform(low=range_min,
                                                                                 high=range_max,
                                                                                 size=1),
                                                            dtype=self.gene_type[gene_idx][0])[0]

                            self.population[sol_idx, gene_idx] = temp_gene_value.copy()
                        elif type(self.gene_space[gene_idx]) in GA.supported_int_float_types:
                            self.population[sol_idx, gene_idx] = self.gene_space[gene_idx]
                        else:
                            # There is no more options.
                            pass
        else:
            # Handle the non-nested gene_space. It can be assigned a numeric value, list, numpy.ndarray, or a dict.
            if self.gene_type_single == True:
                # Reaching this block means:
                # 1) gene_space is not nested (gene_space_nested is False).
                # 2) gene_type is not nested (gene_type_single is True).

                # Replace all the None values with random values using the init_range_low, init_range_high, and gene_type attributes.
                for gene_idx, curr_gene_space in enumerate(self.gene_space):

                    if type(self.init_range_low) in self.supported_int_float_types:
                        range_min = self.init_range_low
                        range_max = self.init_range_high
                    else:
                        range_min = self.init_range_low[gene_idx]
                        range_max = self.init_range_high[gene_idx]

                    if curr_gene_space is None:
                        self.gene_space[gene_idx] = numpy.asarray(numpy.random.uniform(low=range_min,
                                                                                       high=range_max,
                                                                                       size=1),
                                                                  dtype=self.gene_type[0])[0]

                # Creating the initial population by randomly selecting the genes' values from the values inside the 'gene_space' parameter.
                if type(self.gene_space) is dict:
                    if 'step' in self.gene_space.keys():
                        self.population = numpy.asarray(numpy.random.choice(numpy.arange(start=self.gene_space['low'],
                                                                                         stop=self.gene_space['high'],
                                                                                         step=self.gene_space['step']),
                                                                            size=self.pop_size),
                                                        dtype=self.gene_type[0])
                    else:
                        self.population = numpy.asarray(numpy.random.uniform(low=self.gene_space['low'],
                                                                             high=self.gene_space['high'],
                                                                             size=self.pop_size),
                                                        dtype=self.gene_type[
                                                            0])  # A NumPy array holding the initial population.
                else:
                    self.population = numpy.asarray(numpy.random.choice(self.gene_space,
                                                                        size=self.pop_size),
                                                    dtype=self.gene_type[
                                                        0])  # A NumPy array holding the initial population.
            else:
                # Reaching this block means:
                # 1) gene_space is not nested (gene_space_nested is False).
                # 2) gene_type is nested (gene_type_single is False).

                # Creating the initial population by randomly selecting the genes' values from the values inside the 'gene_space' parameter.
                if type(self.gene_space) is dict:
                    # Create an empty population of dtype=object to support storing mixed data types within the same array.
                    self.population = numpy.zeros(shape=self.pop_size,
                                                  dtype=object)
                    # Loop through the genes, randomly generate the values of a single gene across the entire population, and add the values of each gene to the population.
                    for gene_idx in range(self.num_genes):
                        # Generate the values of the current gene across all solutions.
                        # A vector of all values of this single gene across all solutions in the population.
                        if 'step' in self.gene_space.keys():
                            gene_values = numpy.asarray(numpy.random.choice(numpy.arange(start=self.gene_space['low'],
                                                                                         stop=self.gene_space['high'],
                                                                                         step=self.gene_space['step']),
                                                                            size=self.pop_size[0]),
                                                        dtype=self.gene_type[gene_idx][0])
                        else:
                            gene_values = numpy.asarray(numpy.random.uniform(low=self.gene_space['low'],
                                                                             high=self.gene_space['high'],
                                                                             size=self.pop_size[0]),
                                                        dtype=self.gene_type[gene_idx][0])
                        # Adding the current gene values to the population.
                        self.population[:, gene_idx] = gene_values

                else:
                    # Reaching this block means that the gene_space is not None or dict.
                    # It can be either range, numpy.ndarray, or list.

                    # Create an empty population of dtype=object to support storing mixed data types within the same array.
                    self.population = numpy.zeros(shape=self.pop_size, dtype=object)
                    # Loop through the genes, randomly generate the values of a single gene across the entire population, and add the values of each gene to the population.
                    for gene_idx in range(self.num_genes):
                        # A vector of all values of this single gene across all solutions in the population.
                        gene_values = numpy.asarray(numpy.random.choice(self.gene_space,
                                                                        size=self.pop_size[0]),
                                                    dtype=self.gene_type[gene_idx][0])
                        # Adding the current gene values to the population.
                        self.population[:, gene_idx] = gene_values

        if not (self.gene_space is None):
            if allow_duplicate_genes == False:
                for sol_idx in range(self.population.shape[0]):
                    self.population[sol_idx], _, _ = self.solve_duplicate_genes_by_space(
                        solution=self.population[sol_idx],
                        gene_type=self.gene_type,
                        num_trials=10,
                        build_initial_pop=True)

        # Keeping the initial population in the initial_population attribute.
        self.initial_population = self.population.copy()

    def cal_pop_fitness(self, draw=True, pop_use=None):
        """
        Calculating the fitness values of batches of solutions in the current population. 
        It returns:
            -fitness: An Tensor of the calculated fitness values.
        """
        try:
            if not self.valid_parameters:
                raise Exception(
                    "ERROR calling the cal_pop_fitness() method: \nPlease check the parameters passed while creating "
                    "an instance of the GA class.\n")
            if pop_use is None:
                pop_now = self.population
            else:
                pop_now = pop_use
            if self.select_func_flag == 0:
                fitness_func = self.fitness_func0
            elif self.select_func_flag == 1:
                fitness_func = self.fitness_func1
            else:
                fitness_func = self.fitness_func1
            # “last_generation_parents_as_list”是“self.last_generation_parents”的列表版本。
            device = self.len_pop.simulation.device
            pop_fitness = torch.zeros(len(pop_now)).to(device)
            # 计算当前群体中每个解决方案的适合度值。
            solutions_indices = torch.linspace(0, len(pop_now) - 1, len(pop_now)).to(device).long()
            # Number of batches.
            num_batches = int(len(solutions_indices) / self.fitness_batch_size)
            # For each batch, get its indices and call the fitness function.
            for batch_idx in range(num_batches):
                batch_first_index = batch_idx * self.fitness_batch_size
                batch_last_index = (batch_idx + 1) * self.fitness_batch_size
                batch_indices = solutions_indices[batch_first_index:batch_last_index]
                batch_solutions = pop_now[batch_indices, :]
                self.len_pop.simulation.b_size = len(batch_indices)

                batch_fitness = fitness_func(
                    self, batch_solutions, batch_indices, self.len_pop, draw=draw)

                if len(batch_fitness) != len(batch_indices):
                    raise ValueError(
                        f"There is a mismatch between the number of solutions passed to the fitness function "
                        f"({len(batch_indices)}) and the number of fitness values returned ({len(batch_fitness)}).")
                pop_fitness[batch_indices] = batch_fitness

            if len(pop_now) - num_batches * self.fitness_batch_size > 0:
                batch_first_index = num_batches * self.fitness_batch_size
                batch_last_index = len(pop_now)
                batch_indices = solutions_indices[batch_first_index:batch_last_index]
                batch_solutions = pop_now[batch_indices, :]
                self.len_pop.simulation.b_size = len(batch_indices)
                batch_fitness = fitness_func(
                    self, batch_solutions, batch_indices, self.len_pop, draw=draw)
                if len(batch_fitness) != len(batch_indices):
                    raise ValueError(
                        f"There is a mismatch between the number of solutions passed to the fitness function "
                        f"({len(batch_indices)}) and the number of fitness values returned ({len(batch_fitness)}).")
                pop_fitness[batch_indices] = batch_fitness

        except Exception as ex:
            self.logger.exception(ex)
            sys.exit(-1)
        return pop_fitness

    def sa_pso(self, rand_max_min=(1, 0.01), iterMax=1000, min_delta_fit=1e-3, sao_w=0, sao_item=0., end_mean_iter=50, div=0.2, turing_point=0.3, sa_T=0.1):
        i = 0
        device = self.population.device
        mean_fit_all = []
        fit_last = self.cal_pop_fitness(draw=False)

        pop_final = self.population.clone()
        fit_final = fit_last.clone()
        mean_fit_all.append(fit_final.mean())

        sao_v = torch.zeros_like(self.population)
        while i <= iterMax:
            t1 = time.time()
            # 随机变化部分
            rand_range = (rand_max_min[1] - (rand_max_min[1] - rand_max_min[0]) * ((fit_last.max() - fit_last) / (fit_last.max() - fit_last.min() + 1e-8)))
            rand_delta = ((torch.rand(self.population.size()).to(device)).T * rand_range - rand_range / 2).T
            # 实验
            pop_last = self.population.clone()
            # 粒子群算法
            sao_v = (sao_w * sao_v + (1 - sao_w) * (pop_final - self.population)) * sao_item
            delta_all = rand_delta + sao_v
            if not self.op_n:
                delta_all[:, self.len_pop.basics.index_V[0]:self.len_pop.basics.index_V[1]] = 0
            self.population = torch.clamp((pop_last.clone() + delta_all), 0, 1)
            fit_new = self.cal_pop_fitness(draw=False)
            # 最佳种群和适应度转换
            final_replace_idx = fit_final - fit_new > 0
            pop_final[final_replace_idx] = self.population[final_replace_idx].clone()
            fit_final[final_replace_idx] = fit_new[final_replace_idx].clone()
            mean_fit_all.append(fit_final.mean())

            # 当前种群和适应度转换
            diff_fit = fit_last - fit_new

            sa_T = torch.clamp(fit_last * 0.1, max=1)
            p_accept = torch.exp(diff_fit / sa_T)
            rand_accept = torch.rand(self.population.size(0)).to(device)
            index_not_replace = rand_accept > p_accept
            self.population[index_not_replace] = pop_last[index_not_replace].clone()
            fit_new[index_not_replace] = fit_last[index_not_replace].clone()
            fit_last = fit_new.clone()

            self.last_generation_fitness = fit_final.clone()
            _, best_solution_fitness, _ = self.best_solution(
                pop_fitness=self.last_generation_fitness)
            new_mean_fit = fit_final.mean()
            t2 = time.time()
            print('sa_iter:{generation}   time:{time}   bestfit:{bestfit}  mean_fit:{item}'.format(generation=i, bestfit=best_solution_fitness
                                                                                                   , item=new_mean_fit.item(), time=t2-t1))

            if i >= end_mean_iter and (mean_fit_all[-end_mean_iter] - mean_fit_all[-1]) / (end_mean_iter - 1) <= min_delta_fit:
                break
            i = i + 1

        self.population = pop_final

    def adam(self, elitism, iter_num=80, beta1=0.9, beta2=0.9, delta_x=1e-6, lr_base=5e-3, minima_iter=40, cos_T=10, sa_num=20, minima_diff_flag=0.1):

        print('adam:')
        # 计算梯度
        device = elitism.device
        n, l = elitism.size()
        m = torch.zeros(n, l).to(self.device)
        v = torch.zeros(n, l).to(self.device)
        t = torch.zeros(n, l).to(self.device)
        frozen_flag = torch.zeros(n, l).to(self.device).bool()
        elitism = elitism.unsqueeze(1)
        diff = (torch.eye(l) * delta_x).unsqueeze(0).to(device)

        i = 0
        fit_start = self.cal_pop_fitness(draw=False, pop_use=elitism.squeeze(1))
        self.len_pop.constraint.dls_flag = True

        fit_all = []
        pop_final = elitism.squeeze(1).clone()
        fit_final = fit_start.clone()
        fit_all.append(fit_final.clone())
        while i <= iter_num:
            t += 1

            lr = lr_base * torch.ones(1, n).to(self.device)[0] * ((1 + math.cos(i * torch.pi / cos_T)) + 0.2) / 2.2
            item_1 = (elitism + diff).reshape(-1, l)
            item_0 = (elitism - diff).reshape(-1, l)
            item = torch.cat((item_1, item_0), dim=0)
            fit_now = (self.cal_pop_fitness(draw=False, pop_use=item))
            y1 = fit_now[:len(fit_now) // 2].reshape(n, l)
            y0 = fit_now[len(fit_now) // 2:].reshape(n, l)
            grad = ((y1 - y0) / (2 * delta_x))
            m = beta1 * m + (1 - beta1) * grad
            v = beta2 * v + (1 - beta2) * (grad ** 2)
            m_t_hat = m / (1 - beta1 ** t)
            v_t_hat = v / (1 - beta2 ** t)
            delta_x_final = (lr * (m_t_hat / (1e-8 + v_t_hat ** 0.5)).transpose(0, 1)).transpose(0, 1)

            # 实验
            if not self.op_n:
                delta_x_final[..., self.len_pop.basics.index_V[0]:self.len_pop.basics.index_V[1]] = 0

            elitism = torch.clamp((elitism.squeeze(1) - delta_x_final).unsqueeze(1), 0, 1)
            fit_now = self.cal_pop_fitness(draw=False, pop_use=elitism.squeeze(1))

            replace_idx = fit_final - fit_now > 0
            pop_final[replace_idx] = (elitism.squeeze(1))[replace_idx].clone()
            fit_final[replace_idx] = fit_now[replace_idx].clone()
            print('adam_now_mean:{x}'.format(x=fit_final.mean().item()))
            fit_all.append(fit_final.clone())

            if len(fit_all) >= minima_iter + 1:
                diff_rate = (fit_all[-(minima_iter + 1)] - fit_all[-1]) / fit_all[-(minima_iter + 1)]
                if diff_rate.mean() < 0.02 and diff_rate.max() < 0.1:
                    break

            # exp
            i = i + 1

        self.len_pop.constraint.dls_flag = False
        print('adam_good:{x}'.format(x=(fit_start - fit_final).mean().item()))
        return pop_final

    def run(self):
        """
        运行遗传算法。这是遗传算法经过多代进化的主要方法。
        """
        try:
            generation_first_idx = 0
            generation_last_idx = self.num_generations
            # 初始化
            self.select_func_flag = 0
            rand_max_min = (0.1, 0.1)
            iterMax = 300
            min_delta_fit = 0.025

            op_n_num = self.len_pop.diff.op_n_num
            sel_1_num = self.len_pop.diff.sel_1_num

            # Measuring the fitness of each chromosome in the population. Save the fitness in the
            # last_generation_fitness attribute.(
            self.len_pop.basics.final_select_flag = False
            for generation in range(generation_first_idx, generation_last_idx):
                # self.len_pop.diff.weight_constraint = (numpy.cos(generation / op_n_num * math.pi * 4) + 1.1) / 2.1

                print('generation:{generation}: '.format(generation=generation))
                if generation >= op_n_num:
                    self.op_n = True
                else:
                    self.op_n = False

                if generation >= sel_1_num:
                    self.select_func_flag = 1

                self.len_pop.basics.gener_num = generation
                self.len_pop.basics.draw_num = 0

                self.sa_pso(rand_max_min=rand_max_min, iterMax=iterMax, min_delta_fit=min_delta_fit)
                self.last_generation_fitness = self.cal_pop_fitness(draw=False)
                # 筛选母本，每个母本之间有一定的差异性
                self.last_generation_parents = self.select_parents(self.last_generation_fitness, num_parents=self.num_parents_mating)

                # ADAM进一步优化母本
                if generation >= 0:
                    batch_size = self.num_parents_mating // self.keep_elitism
                    for dls_epoch in range(batch_size):
                        select_parent_index = torch.linspace(dls_epoch * self.keep_elitism, (dls_epoch + 1) * self.keep_elitism - 1, self.keep_elitism).to(self.last_generation_parents.device).long()
                        select_parent = self.last_generation_parents[select_parent_index]
                        select_parent2 = self.adam(select_parent)

                        self.last_generation_parents[select_parent_index] = select_parent2
                    self.len_pop.simulation.b_size = len(self.population)

                last_parent_fitness = self.cal_pop_fitness(pop_use=self.last_generation_parents)
                last_parent_sorted = self.last_generation_parents[last_parent_fitness.sort()[1]]
                self.last_generation_elitism = last_parent_sorted[:self.keep_elitism]

                # 将杂交和变异两个步骤
                self.last_generation_offspring_crossover = self.crossover(self.last_generation_parents, offspring_size=(self.num_offspring, self.num_genes))
                self.len_pop.simulation.b_size = len(self.population)
                # 使用突变为后代添加一些变异。
                self.last_generation_offspring_mutation = self.mutation(self.last_generation_offspring_crossover.clone())

                self.population[0:self.last_generation_elitism.shape[0], :] = self.last_generation_elitism
                self.population[self.last_generation_elitism.shape[0]:, :] = self.last_generation_offspring_mutation
                self.generations_completed = generation + 1
                self.previous_generation_fitness = self.last_generation_fitness.clone()
            self.len_pop.basics.final_select_flag = True
            self.cal_pop_fitness()

        except Exception as ex:
            self.logger.exception(ex)
            sys.exit(-1)

    def best_solution(self, pop_fitness=None):
        """
        Returns information about the best solution found by the genetic algorithm.
        Accepts the following parameters:
            pop_fitness: An optional parameter holding the fitness values of the solutions in the latest population.
            If passed, then it save time calculating the fitness.
            If None, then the 'cal_pop_fitness()' method is called to calculate the fitness of the latest population.
        The following are returned:
            -best_solution: Best solution in the current population.
            -best_solution_fitness: Fitness value of the best solution.
            -best_match_idx: Index of the best solution in the current population.
        """
        try:
            if pop_fitness is None:
                pop_fitness = self.cal_pop_fitness()

            # Return the index of the best solution that has the best fitness value.
            best_match_idx = pop_fitness.argmin()
            best_solution = self.population[pop_fitness.argmin()].clone()
            best_solution_fitness = pop_fitness.min()
        except Exception as ex:
            self.logger.exception(ex)
            sys.exit(-1)

        return best_solution, best_solution_fitness, best_match_idx

    def save(self, filename):
        """
        Saves the genetic algorithm instance:
            -filename: Name of the file to save the instance. No extension is needed.
        """

        cloudpickle_serialized_object = cloudpickle.dumps(self)
        with open(filename + ".pkl", 'wb') as file:
            file.write(cloudpickle_serialized_object)
            cloudpickle.dump(self, file)

    def summary(self,
                line_length=70,
                fill_character=" ",
                line_character="-",
                line_character2="=",
                columns_equal_len=False,
                print_step_parameters=True,
                print_parameters_summary=True):
        """
        The summary() method prints a summary of the PyGAD lifecycle in a Keras style.
        The parameters are:
            line_length: An integer representing the length of the single line in characters.
            fill_character: A character to fill the lines.
            line_character: A character for creating a line separator.
            line_character2: A secondary character to create a line separator.
            columns_equal_len: The table rows are split into equal-sized columns or split subjective to the width needed.
            print_step_parameters: Whether to print extra parameters about each step inside the step. If print_step_parameters=False and print_parameters_summary=True, then the parameters of each step are printed at the end of the table.
            print_parameters_summary: Whether to print parameters summary at the end of the table. If print_step_parameters=False, then the parameters of each step are printed at the end of the table too.
        """

        summary_output = ""

        def fill_message(msg, line_length=line_length, fill_character=fill_character):
            num_spaces = int((line_length - len(msg)) / 2)
            num_spaces = int(num_spaces / len(fill_character))
            msg = "{spaces}{msg}{spaces}".format(
                msg=msg, spaces=fill_character * num_spaces)
            return msg

        def line_separator(line_length=line_length, line_character=line_character):
            num_characters = int(line_length / len(line_character))
            return line_character * num_characters

        def create_row(columns, line_length=line_length, fill_character=fill_character, split_percentages=None):
            filled_columns = []
            if split_percentages == None:
                split_percentages = [int(100 / len(columns))] * 3
            columns_lengths = [int((split_percentages[idx] * line_length) / 100)
                               for idx in range(len(split_percentages))]
            for column_idx, column in enumerate(columns):
                current_column_length = len(column)
                extra_characters = columns_lengths[column_idx] - \
                                   current_column_length
                filled_column = column + fill_character * extra_characters
                filled_column = column + fill_character * extra_characters
                filled_columns.append(filled_column)

            return "".join(filled_columns)

        def print_parent_selection_params():
            nonlocal summary_output
            m = f"Number of Parents: {self.num_parents_mating}"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"
            if self.parent_selection_type == "tournament":
                m = f"K Tournament: {self.K_tournament}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"

        def print_fitness_params():
            nonlocal summary_output
            if not self.fitness_batch_size is None:
                m = f"Fitness batch size: {self.fitness_batch_size}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"

        def print_crossover_params():
            nonlocal summary_output
            if not self.crossover_probability is None:
                m = f"Crossover probability: {self.crossover_probability}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"

        def print_mutation_params():
            nonlocal summary_output
            if not self.mutation_probability is None:
                m = f"Mutation Probability: {self.mutation_probability}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"
            if self.mutation_percent_genes == "default":
                m = f"Mutation Percentage: {self.mutation_percent_genes}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"
            # Number of mutation genes is already showed above.
            m = f"Mutation Genes: {self.mutation_num_genes}"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"
            m = f"Random Mutation Range: ({self.random_mutation_min_val}, {self.random_mutation_max_val})"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"
            if not self.gene_space is None:
                m = f"Gene Space: {self.gene_space}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"
            m = f"Mutation by Replacement: {self.mutation_by_replacement}"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"
            m = f"Allow Duplicated Genes: {self.allow_duplicate_genes}"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"

        def print_on_generation_params():
            nonlocal summary_output
            if not self.stop_criteria is None:
                m = f"Stop Criteria: {self.stop_criteria}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"

        def print_params_summary():
            nonlocal summary_output
            m = f"Population Size: ({self.sol_per_pop}, {self.num_genes})"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"
            m = f"Number of Generations: {self.num_generations}"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"
            m = f"Initial Population Range: ({self.init_range_low}, {self.init_range_high})"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"

            if not print_step_parameters:
                print_fitness_params()

            if not print_step_parameters:
                print_parent_selection_params()

            if self.keep_elitism != 0:
                m = f"Keep Elitism: {self.keep_elitism}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"
            else:
                m = f"Keep Parents: {self.keep_parents}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"
            m = f"Gene DType: {self.gene_type}"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"

            if not print_step_parameters:
                print_crossover_params()

            if not print_step_parameters:
                print_mutation_params()

            if self.delay_after_gen != 0:
                m = f"Post-Generation Delay: {self.delay_after_gen}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"

            if not print_step_parameters:
                print_on_generation_params()

            if not self.random_seed is None:
                m = f"Random Seed: {self.random_seed}"
                self.logger.info(m)
                summary_output = summary_output + m + "\n"
            m = f"Save Best Solutions: {self.save_best_solutions}"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"
            m = f"Save Solutions: {self.save_solutions}"
            self.logger.info(m)
            summary_output = summary_output + m + "\n"

        m = line_separator(line_character=line_character)
        self.logger.info(m)
        summary_output = summary_output + m + "\n"
        m = fill_message("PyGAD Lifecycle")
        self.logger.info(m)
        summary_output = summary_output + m + "\n"
        m = line_separator(line_character=line_character2)
        self.logger.info(m)
        summary_output = summary_output + m + "\n"

        lifecycle_steps = ["on_start()", "Fitness Function", "On Fitness", "Parent Selection", "On Parents",
                           "Crossover", "On Crossover", "Mutation", "On Mutation", "On Generation", "On Stop"]
        lifecycle_functions = [self.on_start, self.fitness_func1, self.on_fitness, self.select_parents, self.on_parents,
                               self.crossover, self.on_crossover, self.mutation, self.on_mutation, self.on_generation,
                               self.on_stop]
        lifecycle_functions = [getattr(
            lifecycle_func, '__name__', "None") for lifecycle_func in lifecycle_functions]
        lifecycle_functions = [lifecycle_func + "()" if lifecycle_func !=
                                                        "None" else "None" for lifecycle_func in lifecycle_functions]
        lifecycle_output = ["None", "(1)", "None", f"({self.num_parents_mating}, {self.num_genes})", "None",
                            f"({self.num_parents_mating}, {self.num_genes})", "None",
                            f"({self.num_parents_mating}, {self.num_genes})", "None", "None", "None"]
        lifecycle_step_parameters = [None, print_fitness_params, None, print_parent_selection_params, None,
                                     print_crossover_params, None, print_mutation_params, None,
                                     print_on_generation_params, None]

        if not columns_equal_len:
            max_lengthes = [max(list(map(len, lifecycle_steps))), max(
                list(map(len, lifecycle_functions))), max(list(map(len, lifecycle_output)))]
            split_percentages = [
                int((column_len / sum(max_lengthes)) * 100) for column_len in max_lengthes]
        else:
            split_percentages = None

        header_columns = ["Step", "Handler", "Output Shape"]
        header_row = create_row(
            header_columns, split_percentages=split_percentages)
        m = header_row
        self.logger.info(m)
        summary_output = summary_output + m + "\n"
        m = line_separator(line_character=line_character2)
        self.logger.info(m)
        summary_output = summary_output + m + "\n"

        for lifecycle_idx in range(len(lifecycle_steps)):
            lifecycle_column = [lifecycle_steps[lifecycle_idx],
                                lifecycle_functions[lifecycle_idx], lifecycle_output[lifecycle_idx]]
            if lifecycle_column[1] == "None":
                continue
            lifecycle_row = create_row(
                lifecycle_column, split_percentages=split_percentages)
            m = lifecycle_row
            self.logger.info(m)
            summary_output = summary_output + m + "\n"
            if print_step_parameters:
                if not lifecycle_step_parameters[lifecycle_idx] is None:
                    lifecycle_step_parameters[lifecycle_idx]()
            m = line_separator(line_character=line_character)
            self.logger.info(m)
            summary_output = summary_output + m + "\n"

        m = line_separator(line_character=line_character2)
        self.logger.info(m)
        summary_output = summary_output + m + "\n"
        if print_parameters_summary:
            print_params_summary()
            m = line_separator(line_character=line_character2)
            self.logger.info(m)
            summary_output = summary_output + m + "\n"
        return summary_output


def load(filename):
    """
    Reads a saved instance of the genetic algorithm:
        -filename: Name of the file to read the instance. No extension is needed.
    Returns the genetic algorithm instance.
    """

    try:
        with open(filename + ".pkl", 'rb') as file:
            ga_in = cloudpickle.load(file)
    except FileNotFoundError:
        raise FileNotFoundError(f"Error reading the file {filename}. Please check your inputs.")
    except:
        # raise BaseException("Error loading the file. If the file already exists, please reload all the functions previously used (e.g. fitness function).")
        raise BaseException("Error loading the file.")
    return ga_in
