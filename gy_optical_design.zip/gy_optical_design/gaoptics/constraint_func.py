class Constraint:
    def __init__(self):
        self.thi_glass_cen = None
        self.thi_glass_border = None
        self.thi_air_cen = None
        self.thi_air_border = None
        self.material_n = None
        self.material_V = None
        self.fov = None
        self.bfl = None
        self.c = None
        self.k = None
        self.aspheric = None
        self.z_sensor = None
        self.defocus = None
        self.aper_d = None
        self.effl = None
        self.edge_ray = None
        self.dls_flag = False
        self.distort = None
        self.img = None

