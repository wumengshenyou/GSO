import os

import torch
import time
import matplotlib.pyplot as plt
import matplotlib.tri as tri
import meshio
import torch.nn.functional as F
from torchvision.transforms.functional import InterpolationMode, resize
from torchvision import utils
import numpy as np
from .order1_func import Order1
from .constraint_func import Constraint
from .simulation_func import Simulation
from .diff_func import Diff
from .ga_basics import *


# 绘制透镜界面：316~568行
# 光线采样：610~875行
class Path:
    def __init__(self):
        self.optics_read_path = None
        self.clear_root = None
        self.blur_root = None
        self.input_root = None
        self.demo_root = None
        self.save_root = None


class Basics:
    def __init__(self):
        self.z_object = None
        self.z_sensor = None
        self.z_object_edof = None
        self.surfaces = None
        self.materials = None
        self.aper_index = None
        self.min_F_num = None
        self.F_num_all = None
        self.MAX_R = None
        self.defocus = None
        self.aper_R = None

        self.surface_num = None
        self.piece_num = None
        self.aspheric_order = []
        self.aspheric_list = []
        self.conic_list = []
        self.sphere_list = []
        self.material_list = []
        self.d_list = []
        self.aper_list = []

        self.index_c = None
        self.index_d = None
        self.index_k = None
        self.index_n = None
        self.index_V = None
        self.index_asp = None
        self.index_defocus = None

        self.len_inputs = None
        self.phi_inf = None
        self.valid_idx = None
        self.valid_idx_now = None

        self.img_r = None

        self.gener_num = 0
        self.draw_num = 0
        self.exp_num = 0
        self.exp_z_sensor = []

        self.fit_all = None

        self.acc_fit = None
        self.acc_fit_all = None
        self.distort_all = None
        self.acc_range = None
        self.acc_data = None

        self.val_flag = False
        self.final_select_flag = True


class LensPopulation:
    """
    定义透镜组，分为基本数据和高阶数据
    除波长外单位一般均为[mm]
    位置是相对透镜组第一个透镜面（不包括孔径光阑）的距离
    """

    def __init__(self):
        self.basics = Basics()
        self.simulation = Simulation()
        self.constraint = Constraint()
        self.order1 = Order1()
        self.diff = Diff()
        self.path = Path()

    def init_pop(self, sol_per_pop):
        device = self.simulation.device
        self.basics.surface_num = self.basics.piece_num * 2 + 1
        self.basics.sphere_list = np.linspace(0, self.basics.piece_num * 2, self.basics.piece_num * 2 + 1).astype(
            int).tolist()
        del self.basics.sphere_list[self.basics.aper_index]

        self.basics.d_list = np.linspace(0, self.basics.piece_num * 2 - 1, self.basics.piece_num * 2).astype(
            int).tolist()
        self.basics.material_list = []
        self.basics.aper_list = []
        for i in range(self.basics.piece_num * 2):
            if (((i - self.basics.aper_index) % 2 == 1) and (i - self.basics.aper_index > 0)) or (
                    ((self.basics.aper_index - i) % 2 == 0) and (i - self.basics.aper_index < 0)):
                self.basics.material_list.append(i)
            if 0 <= self.basics.aper_index - i <= 1:
                self.basics.aper_list.append(i)

        self.basics.index_c = (0, len(self.basics.sphere_list))
        self.basics.index_d = (self.basics.index_c[1], self.basics.index_c[1] + len(self.basics.d_list))
        self.basics.index_n = (self.basics.index_d[1], self.basics.index_d[1] + len(self.basics.material_list))
        self.basics.index_V = (self.basics.index_n[1], self.basics.index_n[1] + len(self.basics.material_list))

        self.basics.index_k = (self.basics.index_V[1], self.basics.index_V[1] + len(self.basics.conic_list))
        self.basics.index_asp = (self.basics.index_k[1], self.basics.index_k[1] +
                                 len(self.basics.aspheric_list) * len(self.basics.aspheric_order))
        self.basics.index_defocus = (self.basics.index_asp[1], self.basics.index_asp[1] + 1)
        self.basics.len_inputs = self.basics.index_defocus[1]

        self.basics.phi_inf = torch.zeros(self.basics.len_inputs, 2).to(device)
        self.basics.phi_inf[self.basics.index_c[0]: self.basics.index_c[1]] = \
            torch.Tensor([self.constraint.c[0], self.constraint.c[1] - self.constraint.c[0]]).to(device)
        self.basics.phi_inf[self.basics.index_n[0]: self.basics.index_n[1]] = \
            torch.Tensor([self.constraint.material_n[0]
                             , self.constraint.material_n[1] - self.constraint.material_n[0]]).to(device)
        self.basics.phi_inf[self.basics.index_V[0]: self.basics.index_V[1]] = \
            torch.Tensor([self.constraint.material_V[0]
                             , self.constraint.material_V[1] - self.constraint.material_V[0]]).to(device)
        self.basics.phi_inf[self.basics.index_defocus[0]: self.basics.index_defocus[1]] = \
            torch.Tensor([self.constraint.defocus[0]
                             , self.constraint.defocus[1] - self.constraint.defocus[0]]).to(device)

        if self.constraint.k is not None:
            self.basics.phi_inf[self.basics.index_k[0]: self.basics.index_k[1]] = \
                torch.Tensor([self.constraint.k[0], self.constraint.k[1] - self.constraint.k[0]]).to(device)
        for i in range(len(self.basics.d_list)):
            if i in self.basics.material_list:
                self.basics.phi_inf[self.basics.index_d[0] + i] = \
                    torch.Tensor([self.constraint.thi_glass_cen[0],
                                  self.constraint.thi_glass_cen[1] - self.constraint.thi_glass_cen[0]]).to(device)
            elif i in self.basics.aper_list:
                self.basics.phi_inf[self.basics.index_d[0] + i] = \
                    torch.Tensor([self.constraint.aper_d[0],
                                  self.constraint.aper_d[1] - self.constraint.aper_d[0]]).to(device)
            else:
                self.basics.phi_inf[self.basics.index_d[0] + i] = \
                    torch.Tensor([self.constraint.thi_air_cen[0],
                                  self.constraint.thi_air_cen[1] - self.constraint.thi_air_cen[0]]).to(device)
        if self.constraint.aspheric is not None:
            for i in range(len(self.basics.aspheric_order)):
                item = self.constraint.aspheric[i]
                self.basics.phi_inf[self.basics.index_asp[0] + i * len(self.basics.aspheric_list):
                                    self.basics.index_asp[0] + (i + 1) * len(self.basics.aspheric_list)] = \
                    torch.Tensor([item[0], item[1] - item[0]]).to(device)

        res = 0.5 * torch.ones(sol_per_pop, self.basics.len_inputs).to(device) + torch.rand(sol_per_pop, self.basics.len_inputs).to(device) * 1e-3
        return res

    def set_basics(self, sol):
        device = self.simulation.device
        sol = self.basics.phi_inf[:, 0] + self.basics.phi_inf[:, 1] * sol
        sol = sol.transpose(0, 1)
        r_init = torch.ones(sol.size(1)).to(device) * self.basics.MAX_R
        # 定义表面
        sol_c = sol[self.basics.index_c[0]: self.basics.index_c[1]]
        sol_d = sol[self.basics.index_d[0]: self.basics.index_d[1]]

        sol_n = sol[self.basics.index_n[0]: self.basics.index_n[1]]
        sol_V = sol[self.basics.index_V[0]: self.basics.index_V[1]]
        sol_k = sol[self.basics.index_k[0]: self.basics.index_k[1]]
        sol_asp = sol[self.basics.index_asp[0]: self.basics.index_asp[1]]
        self.basics.defocus = sol[self.basics.index_defocus[0]: self.basics.index_defocus[1]]

        if self.basics.val_flag:
            # GSO结果统计
            self.basics.exp_z_sensor = []

            read_path = './init_structure/exp.txt'
            with open(read_path, 'r', encoding='utf-8') as f:  # 使用with open()新建对象f
                contents = f.readlines()
                read_num = 0
                i = 0
                while i < len(contents):
                    if contents[i][:3] == 'num':
                        idx_c = 0
                        idx_material = 0
                        idx_d = 0
                        # 孔阑位置
                        while contents[i + 2] != 'end\n':
                            content = str.split(contents[i + 2])
                            if int(content[0]) != self.basics.aper_index:
                                sol_c[idx_c, read_num] = 1 / float(content[1])
                                idx_c += 1

                            if int(content[0]) < self.basics.piece_num * 2:
                                sol_d[idx_d, read_num] = float(content[2])
                                idx_d += 1

                            if int(content[0]) == self.basics.piece_num * 2:
                                self.basics.exp_z_sensor.append(float(content[2]))

                            if float(content[3]) > 1.003:
                                sol_n[idx_material, read_num] = float(content[3])
                                sol_V[idx_material, read_num] = float(content[4])
                                idx_material += 1
                            i += 1
                        read_num += 1
                    else:
                        i += 1
                f.close()
                self.basics.defocus = self.basics.defocus * 0
                self.basics.exp_num = 1

        sol_d = sol_d.cumsum(dim=0)
        sol_d = torch.cat((torch.zeros(1, sol_d.size(1)).to(device), sol_d), dim=0)
        self.basics.surfaces = []
        idx_asp = 0
        idx_material = 0
        idx_k = 0
        idx_c = 0
        self.basics.materials = [Material(device=device, name='air', size_pop=sol.size(1))]
        for i in range(self.basics.surface_num):
            if i in self.basics.aspheric_list:
                ai_index = []
                for j in range(len(self.basics.aspheric_order)):
                    ai_index.append(idx_asp + j * len(self.basics.aspheric_list))
                ai_item = sol_asp[ai_index]

                surface = Aspheric(sol_c[idx_c], sol_d[i], r_init, k=sol_k[idx_k], ai=ai_item, device=device)
                idx_asp = idx_asp + 1
                idx_k = idx_k + 1
                idx_c = idx_c + 1

            elif i == self.basics.aper_index:
                surface = Aspheric(torch.ones_like(sol_c[0]) * 1e-10, sol_d[i], r_init, device=device)
            else:
                surface = Aspheric(sol_c[idx_c], sol_d[i], r_init, device=device)
                idx_c = idx_c + 1
            self.basics.surfaces.append(surface)
            if i in self.basics.material_list:
                mater_item = Material(device=device, data=[sol_n[idx_material], sol_V[idx_material]])
                idx_material = idx_material + 1
            else:
                mater_item = Material(device=device, name='air', size_pop=sol.size(1))
            self.basics.materials.append(mater_item)
        self.basics.valid_idx = torch.ones(sol.size(1)).bool().to(device)

    def calc_order1(self, calc_zoom_rate=False, flag_calc_exit=False, cal_time=True):
        t1 = time.time()
        device = self.simulation.device
        wavelength_all = self.simulation.wavelength
        self.order1.wave_data = {
            "all": wavelength_all['R'][0] + wavelength_all['G'][0] + wavelength_all['B'][0],
            "all_weight": wavelength_all['R'][1] + wavelength_all['G'][1] + wavelength_all['B'][1],
            "main_RGB": [np.median(wavelength_all['R'][0]), np.median(wavelength_all['G'][0]),
                         np.median(wavelength_all['B'][0])],
            "main": float(np.median(wavelength_all['G'][0]))
        }
        self.basics.min_F_num = self.basics.F_num_all[self.basics.gener_num]
        self.order1.aperture_max = self.calc_max_aper(
            wavelength=self.order1.wave_data["main"], resume=True)
        # 此时也需要re_valid
        self.re_valid_func(self.basics.valid_idx)

        if self.simulation.flag_auto_calc:
            self.order1.aperture_max[self.order1.aperture_max < self.basics.aper_R[0]] = self.basics.aper_R[0]
            self.order1.aperture_max[self.order1.aperture_max > self.basics.aper_R[1]] = self.basics.aper_R[1]

            self.basics.surfaces[self.basics.aper_index].r = self.order1.aperture_max

        if calc_zoom_rate:
            self.order1.zoom_rate = self.calc_room_rate(wavelength=self.order1.wave_data["main"], view=0.0)  # 计算近轴放大率
        t2 = time.time()  # 运行时间计算

        if self.simulation.fov_hand_set is not None:
            self.order1.fov_max = self.simulation.fov_hand_set[self.basics.gener_num] * torch.ones(
                self.basics.valid_idx.sum()).to(device)
        else:
            self.order1.fov_max = self.calc_max_fov(wavelength=self.order1.wave_data["main"],
                                                    M=self.simulation.enp_num ** 2 * 3)

        t3 = time.time()  # 运行时间计算

        # if self.simulation.flag_auto_calc:
        #     self.resize_lens(wavelength=self.order1.wave_data["main"], view=self.order1.fov_max,
        #                      vignetting=1, M=self.simulation.enp_num ** 2 * 3)

        t4 = time.time()
        self.order1.fov_samples, self.order1.fov_pos = self.calc_fov_samples(self.order1.fov_max,
                                                                             self.order1.wave_data["main_RGB"],
                                                                             non_uniform=False)

        # 3、计算得到每个视场下主波长光线在第一面的入瞳坐标与相对照度（渐晕）因子, 尝试与resize_lens合并
        self.order1.enp_xy, self.order1.vignetting_factors = self.calc_enp_all_fov(
            wavelength=self.order1.wave_data["main"])
        t5 = time.time()

        if cal_time:
            print('time_aper:{time}'.format(time=t2 - t1))
            print('time_fov:{time}'.format(time=t3 - t2))
            print('time_resize:{time}'.format(time=t4 - t3))
            print('time_enp:{time}'.format(time=t5 - t4))

        # 暂时没什么用
        if flag_calc_exit:
            self.calc_exit_pupil()

    def fit_constraint_func(self, x, bound, scale_pos=None, exponent=1, zero_rate=0.05):
        exponent = 1
        min_x = bound[0]
        max_x = bound[1]
        if self.constraint.dls_flag:
            scale_x = (max_x - min_x) * 0
        else:
            scale_x = (max_x - min_x) * 0
        max_item = max_x - scale_x
        min_item = min_x + scale_x
        cen = (max_item + min_item) / 2
        loss_con = torch.zeros_like(x)
        loss_con[x > max_item] = (x - max_item)[x > max_item]
        loss_con[x < min_item] = (min_item - x)[x < min_item]
        # loss_con[x > max_item] = ((2 / (max_item - min_item) * (x - cen)) ** exponent - 1)[x > max_item]
        # loss_con[x < min_item] = ((2 / (max_item - min_item) * (cen - x)) ** exponent - 1)[x < min_item]

        # 指数型，梯度容易爆炸，慎用
        # h = (max_x - min_x) * scale_pos
        # b = scale ** (-1 / h)
        # loss_con = b**(x-max_x) + b**(min_x-x)

        # 幂函数型，幂指数设置为10
        # cen = (max_x + min_x) / 2
        # diff = (max_x - min_x) / 2
        # a = scale * diff ** (-exponent)
        # loss_con = a * (x - cen) ** exponent

        # h = (max_x - min_x) * scale_pos
        # y = np.linspace(min_x-h, max_x+h, 1000)
        # loss = a*(y-cen)**exponent
        # fig = plt.figure()
        # ax = plt.axes()
        # ax.plot(y, loss)
        # plt.xlabel('x ')
        # plt.ylabel('loss')
        # fig.savefig('./autodiff_demo/loss_constraint.png', bbox_inches='tight')
        # y = np.linspace(min_x-h, max_x+h, 1000)
        # loss = b ** (y - max_x) + b ** (min_x - y)
        # fig = plt.figure()
        # ax = plt.axes()
        # ax.plot(y, loss)
        # plt.xlabel('x ')
        # plt.ylabel('loss')
        # fig.savefig('./autodiff_demo/loss_constraint.png', bbox_inches='tight')

        return loss_con

    def calc_fit_aberration(self, weight_rms=100, weight_ray_angle=5000, M=4, weight_img=1000, weight_edge_ray=100, weight_fov=0.5):
        num_obj = len(self.basics.z_object_edof)
        idx = (self.basics.gener_num + num_obj // 2) % num_obj
        # idx = torch.randint(num_obj, (1,))[0].item()
        self.basics.z_object = self.basics.z_object_edof[idx]
        views = self.order1.fov_samples
        wave_all_data = self.order1.wave_data["all"]
        size_pop_now = self.basics.valid_idx.sum()
        device = self.simulation.device
        self.basics.valid_idx_now = torch.ones(self.basics.valid_idx.sum()).to(device).bool()
        fit_edge_ray = torch.zeros(size_pop_now).to(device)
        M2 = M ** 2
        RMS_all = torch.zeros(self.simulation.fov_num, size_pop_now).to(device)
        pen_all = torch.zeros(self.simulation.fov_num, size_pop_now).to(device)
        self.diff.loss_raytrace_flag = True
        self.diff.loss_raytrace_num = torch.zeros(size_pop_now).to(device)
        self.diff.loss_raytrace = torch.zeros(size_pop_now).to(device)
        wave_len = wave_all_data[len(wave_all_data) // 2]
        ray_o = torch.zeros(3, M2 * self.simulation.fov_num, size_pop_now).to(device)
        ray_d = torch.zeros(3, M2 * self.simulation.fov_num, size_pop_now).to(device)
        for i in range(self.simulation.fov_num):
            fov = views[i]
            ray = self.sample_ray_common(wave_len, view=fov, pos=self.order1.enp_xy[:, i], M=M)
            ray_o[:, i * M2:(i + 1) * M2] = ray.o
            ray_d[:, i * M2:(i + 1) * M2] = ray.d

        ray_all = Ray(ray_o, ray_d, wave_len)
        valid_all, ray_final_all, _ = self._trace(ray_all, record=True)

        for i in range(self.simulation.fov_num):
            valid = valid_all[i * (M * M):(i + 1) * (M * M)]
            ray_o = ray_final_all.o[:, i * (M * M):(i + 1) * (M * M)]
            ray_d = ray_final_all.d[:, i * (M * M):(i + 1) * (M * M)]
            t = (self.basics.z_sensor - ray_o[2]) / ray_d[2]
            p_img = ray_o + t * ray_d

            # 特定损失设置
            if i == self.simulation.fov_num - 1:
                t_item = (self.basics.z_sensor - 10 - ray_o[2]) / ray_d[2]
                p_item = ray_o + t_item * ray_d
                max_pos = p_item[0:2].square().sum(dim=0).sqrt().max(dim=0).values
                fit_edge_ray[max_pos > self.constraint.edge_ray] = weight_edge_ray * \
                                                                   ((max_pos - self.constraint.edge_ray)[
                                                                       max_pos > self.constraint.edge_ray] ** 1)
            # 通过RMS直径的1.5倍(经验值)作为psf范围
            RMS_all[i], pen_all[i] = self.rms(p_img, valid=valid)

        self.diff.loss_raytrace_flag = False
        # 光线角度损失
        fit_ray_angle = weight_ray_angle * self.diff.loss_raytrace

        # RMS半径损失
        fit_rms = weight_rms * (RMS_all.mean(dim=0))

        fit_fov = RMS_all.max(dim=0).values - RMS_all.min(dim=0).values

        fit_img = torch.zeros_like(fit_rms)

        for i in range(self.simulation.fov_num):
            img_weight = self.order1.fov_pos[i]
            if i > 0:
                self.basics.distort_all.append(
                    (pen_all[i] + self.basics.img_r * img_weight) / (self.basics.img_r * img_weight))
            # if i > 0:
            #     if i != self.simulation.fov_num - 1:
            #         rate = 0.1
            #
            #     else:
            #         rate = 1
            #         fit_img = fit_img + rate * weight_distort * (
            #                 ((pen_all[i].mean(dim=0) + self.basics.img_r * img_weight).abs()) ** 1)
            if i < self.simulation.fov_num - 1:
                fit_img[pen_all[i + 1] > pen_all[i]] = fit_img[pen_all[i + 1] > pen_all[i]] + 1

        self.basics.z_object = self.basics.z_object_edof[num_obj // 2]
        return fit_rms + weight_fov * fit_fov, fit_img + fit_ray_angle + fit_edge_ray

    def calc_fit_rms(self, weight_rms=1, weight_color=0.25, weight_distort=1, weight_ray_angle=0, M=32,
                     weight_edge_ray=0, weight_fov=0.5, weight_defocus=0.0):
        """
        2023.11.19 加入视场先验和景深先验
        :param weight_defocus:
        :param weight_fov:
        :param weight_rms:
        :param weight_color:
        :param weight_img:
        :param weight_ray_angle:
        :param M:
        :param weight_edge_ray:
        :return:
        """
        # self.basics.valid_idx[self.basics.valid_idx.clone()] = self.basics.valid_idx_now.clone()
        # self.re_valid_func(self.basics.valid_idx_now)
        num_obj = len(self.basics.z_object_edof)
        views = self.order1.fov_samples
        wave_all_data = self.order1.wave_data["all"]
        size_pop_now = self.basics.valid_idx.sum()
        device = self.simulation.device
        self.basics.valid_idx_now = torch.ones(self.basics.valid_idx.sum()).to(device).bool()
        M2 = M ** 2
        fit_aber = []
        fit_img_all = []
        fit_fov_all = []
        RMS_balance = []
        for num in range(num_obj):
            self.basics.z_object = self.basics.z_object_edof[num]
            RMS_all = torch.zeros(self.simulation.fov_num, len(wave_all_data), size_pop_now).to(device)
            pen_all = torch.zeros(self.simulation.fov_num, len(wave_all_data), size_pop_now).to(device)
            fit_edge_ray = torch.zeros(len(wave_all_data), size_pop_now).to(device)
            self.diff.loss_raytrace_flag = True
            self.diff.loss_raytrace_num = torch.zeros(size_pop_now).to(device)
            self.diff.loss_raytrace = torch.zeros(size_pop_now).to(device)
            for j, wave_len in enumerate(wave_all_data):
                ray_o = torch.zeros(3, M2 * self.simulation.fov_num, size_pop_now).to(device)
                ray_d = torch.zeros(3, M2 * self.simulation.fov_num, size_pop_now).to(device)
                for i in range(self.simulation.fov_num):
                    fov = views[i]
                    ray = self.sample_ray_common(wave_len, view=fov, pos=self.order1.enp_xy[:, i], M=M)
                    ray_o[:, i * M2:(i + 1) * M2] = ray.o
                    ray_d[:, i * M2:(i + 1) * M2] = ray.d

                ray_all = Ray(ray_o, ray_d, wave_len)
                valid_all, ray_final_all, _ = self._trace(ray_all, record=True)

                for i in range(self.simulation.fov_num):
                    valid = valid_all[i * (M * M):(i + 1) * (M * M)]
                    ray_o = ray_final_all.o[:, i * (M * M):(i + 1) * (M * M)]
                    ray_d = ray_final_all.d[:, i * (M * M):(i + 1) * (M * M)]
                    t = (self.basics.z_sensor - ray_o[2]) / ray_d[2]
                    p_img = ray_o + t * ray_d
                    # 特定损失设置
                    if i == self.simulation.fov_num - 1:
                        t_item = (self.basics.z_sensor - 10 - ray_o[2]) / ray_d[2]
                        p_item = ray_o + t_item * ray_d
                        max_pos = p_item[0:2].square().sum(dim=0).sqrt().max(dim=0).values
                        fit_edge_ray[j, max_pos > self.constraint.edge_ray] = weight_edge_ray * \
                                                                              ((max_pos - self.constraint.edge_ray)[
                                                                                  max_pos > self.constraint.edge_ray] ** 1)
                    # 通过RMS直径的1.5倍(经验值)作为psf范围
                    RMS_all[i, j], pen_all[i, j] = self.rms(p_img, valid=valid)
                    # RMS_all[i, j] = 10 * (RMS_all[i, j] ** 2)

            self.diff.loss_raytrace_flag = False
            # 光线角度损失
            fit_ray_angle = weight_ray_angle * self.diff.loss_raytrace
            RMS_balance.append(RMS_all)

            fit_fov_all.append(RMS_all.mean(dim=1).max(dim=0).values - RMS_all.mean(dim=1).min(dim=0).values)
            # RMS半径损失
            fit_rms = weight_rms * (RMS_all.mean(dim=0).mean(dim=0))
            item_color = torch.clamp(((pen_all[:, 2] - pen_all[:, 1]).abs() + (pen_all[:, 0] - pen_all[:, 1]).abs() + 0.1 * ((RMS_all[:, 2] - RMS_all[:, 1]).abs() + (RMS_all[:, 0] - RMS_all[:, 1]).abs())), min=1e-8).mean(
                dim=0)

            fit_color = weight_color * item_color

            fit_img = torch.zeros_like(fit_rms)
            for i in range(self.simulation.fov_num):
                img_weight = self.order1.fov_pos[i]
                if i > 0:
                    self.basics.distort_all.append((pen_all[i].mean(dim=0) + self.basics.img_r * img_weight) / (self.basics.img_r * img_weight))
                # if i > 0:
                #     if i != self.simulation.fov_num - 1:
                #         rate = 0.1
                #
                #     else:
                #         rate = 1
                #         fit_img = fit_img + rate * weight_distort * (
                #                 ((pen_all[i].mean(dim=0) + self.basics.img_r * img_weight).abs()) ** 1)
                if i < self.simulation.fov_num - 1:
                    fit_img[pen_all[i + 1].mean(dim=0) > pen_all[i].mean(dim=0)] = fit_img[pen_all[i + 1].mean(dim=0) > pen_all[i].mean(dim=0)] + weight_distort * 10
            fit_img_all.append(fit_img + fit_ray_angle + fit_edge_ray.mean(dim=0))
            fit_aber.append(fit_rms + fit_color)
        # 设置损失函数让各视场和景深退化更均匀
        fit_defocus = ((RMS_balance[-1] - RMS_balance[num_obj // 2]).abs() + (RMS_balance[0] - RMS_balance[num_obj // 2]).abs()).mean(dim=0).mean(dim=0) / 2
        fit_fov = sum(fit_fov_all) / len(fit_fov_all)
        self.basics.z_object = self.basics.z_object_edof[num_obj // 2]
        return sum(fit_aber) / len(fit_aber) + fit_fov * weight_fov + fit_defocus * weight_defocus, fit_img_all[num_obj // 2]

    def calc_fit_constraint(self, weight_board=1, weight_fov=1, weight_z_sensor=1, weight_bfl=1, weight_distort=0.1
                            , weight_relative=1, weight_enp=1, weight_effl=1, weight_aper_pos=1, weight_price=0.3, mater_path='./materials.txt'):
        surfaces = self.basics.surfaces
        device = self.simulation.device
        loss_limits = []
        # 生成材料表, 用于粗略估计成本
        price_constraint = []
        material_constraint = []
        V_all = []
        n_all = []
        price_all = []
        with open(mater_path, 'r', encoding='utf-8') as f:  # 使用with open()新建对象f
            contents = f.readlines()
            for ii in range(len(contents)):
                content = str.split(contents[ii])
                n_all.append(((float(content[1][:3]) / 1000 + 1) - self.constraint.material_n[0]) / (self.constraint.material_n[1] - self.constraint.material_n[0]))
                V_all.append(((float(content[1][3:]) / 10) - self.constraint.material_V[0]) / (self.constraint.material_V[1] - self.constraint.material_V[0]))
                price_all.append(float(content[2]))
        n_all = torch.Tensor(n_all).to(device)
        V_all = torch.Tensor(V_all).to(device)
        price_all = torch.Tensor(price_all).to(device)
        # 透镜间隔和材料的物理约束
        for i in range(len(surfaces) - 1):
            sag2 = surfaces[i + 1].surface(surfaces[i + 1].r, 0.0)
            sag1 = surfaces[i].surface(surfaces[i].r, 0.0)
            d_border = (surfaces[i + 1].d + sag2) - (surfaces[i].d + sag1)
            invalid_rate = torch.ones_like(d_border)
            invalid_rate[d_border < 0] = 10
            if i in self.basics.material_list:
                loss_limits.append(self.fit_constraint_func(d_border, self.constraint.thi_glass_border, exponent=1) * weight_board * invalid_rate)

                # 计算材料成本
                n_now = (self.basics.materials[i + 1].n - self.constraint.material_n[0]) / (self.constraint.material_n[1] - self.constraint.material_n[0])
                V_now = (self.basics.materials[i + 1].V - self.constraint.material_V[0]) / (self.constraint.material_V[1] - self.constraint.material_V[0])
                n_diff = n_all.unsqueeze(1) - n_now.unsqueeze(0)
                V_diff = V_all.unsqueeze(1) - V_now.unsqueeze(0)
                distance = (n_diff ** 2 + V_diff ** 2).min(dim=0)[1]
                # distance = distance / distance.sum(dim=0)
                price_now = price_all[distance]
                # 计算相对体积, 半径作为长和宽, 前后厚度作为高的立方体
                sag2[sag2 < 0] = 0
                sag1[sag1 > 0] = 0
                h = (surfaces[i + 1].d + sag2) - (surfaces[i].d + sag1)
                volume = ((self.basics.surfaces[i].r * 2) ** 2 * h) / 1000000

                price_constraint.append(price_now * volume)
                material_constraint.append((n_diff ** 2 + (V_diff / 2) ** 2).sqrt().min(dim=0).values)
            elif i in self.basics.aper_list:
                loss_limits.append(
                    self.fit_constraint_func(d_border, self.constraint.aper_d, exponent=1) * weight_board * invalid_rate)
            else:
                loss_limits.append(
                    self.fit_constraint_func(d_border, self.constraint.thi_air_border, exponent=1) * weight_board * invalid_rate)

        # 成本约束
        # loss_price = (sum(price_constraint) / len(price_constraint) + sum(material_constraint) / len(material_constraint)) * weight_price

        loss_price = sum(material_constraint) / len(material_constraint) * weight_price

        # 最后一面和像面距离，后截距
        sag1 = surfaces[-1].surface(surfaces[-1].r, 0.0)
        sag1[sag1 < 0] = 0
        d_border = self.basics.z_sensor - (surfaces[-1].d + sag1)
        loss_limits.append(self.fit_constraint_func(d_border, self.constraint.bfl, exponent=1) * weight_bfl)

        # 像面位置，也即是系统总长
        loss_limits.append(
            self.fit_constraint_func(self.basics.z_sensor, self.constraint.z_sensor, exponent=1) * weight_z_sensor)

        # 焦距物理约束
        loss_limits.append(
            self.fit_constraint_func(self.order1.effl, self.constraint.effl, exponent=1) * weight_effl)

        # 最大视场角的物理约束
        # loss_limits.append(self.fit_constraint_func(self.order1.fov_max, self.constraint.fov, exponent=1) * weight_fov)

        # 相对照度约束
        loss_relative = 1 - self.order1.vignetting_factors.min(dim=0).values
        # loss_relative = ((loss_relative * 1.5) ** 8)
        loss_relative = loss_relative - 0.7
        loss_relative[loss_relative < 0] = 0

        loss_limits.append(loss_relative * weight_relative)

        # 入瞳位置约束
        enp_pos = self.order1.enp_xy[0].mean(dim=0)
        loss_enp = torch.zeros_like(enp_pos)
        loss_enp[enp_pos < -surfaces[0].r * 0.01] = weight_enp
        if self.basics.aper_index > 0:
            for i in range(self.simulation.fov_num - 1):
                item_enp = self.order1.enp_xy[0, i + 1] - self.order1.enp_xy[0, i]
                loss_enp[item_enp < surfaces[0].r * 0.01] = loss_enp[item_enp < surfaces[0].r * 0.01] + weight_enp
        loss_limits.append(loss_enp)

        # 孔阑位置约束, 零视场光线没有基本充满孔阑的和边缘视场追迹不到主光线的
        loss_aper_pos = (self.order1.aper_flag - 0.5) * weight_aper_pos
        loss_aper_pos[loss_aper_pos < 0] = 0
        loss_limits.append(loss_aper_pos)

        # 畸变
        loss_distort = torch.zeros_like(enp_pos)
        for i in range(len(self.basics.distort_all)):
            if (i + 1) % (len(self.order1.fov_pos) - 1) == 0:
                loss_distort = loss_distort + self.fit_constraint_func(self.basics.distort_all[i], self.constraint.img, exponent=1)

            else:
                loss_distort = loss_distort + self.fit_constraint_func(self.basics.distort_all[i], self.constraint.distort, exponent=1)
        loss_limits.append(loss_distort * weight_distort)

        return sum(loss_limits), loss_price

    # ------------------------------------------------------------------------------------
    # 画图
    # ------------------------------------------------------------------------------------
    def draw_all(self, M=11, sort_index=None):
        num = self.basics.gener_num
        now_valid_index = torch.where(self.basics.valid_idx)[0]
        now_sort_index = torch.zeros_like(sort_index)
        for i in range(len(sort_index)):
            now_sort_index[i] = torch.nonzero(now_valid_index == sort_index[i])[0][0]
        self.re_valid_func(now_sort_index)
        self.basics.valid_idx[:] = False
        self.basics.valid_idx[sort_index] = True

        with torch.no_grad():
            # 光线追迹可视化
            for i in range(len(now_sort_index)):
                fit_item = self.basics.fit_all[sort_index[i]].item()
                ax, fig = self.plot_setup2D_with_trace_whole(self.order1.wave_data["main"], M=M, index=i)
                ax.axis('off')
                title_name = "ray_gen{num}_{count}_fit{fit}".format(num=num, count=self.basics.draw_num
                                                                    , fit=round(fit_item, 2))
                ax.set_title(title_name)
                name = self.path.demo_root + title_name + ".png"

                fig.savefig(name, bbox_inches='tight')
                plt.close()
                self.basics.draw_num = self.basics.draw_num + 1

    def spot_diagram(self, ps, show=True, x_lims=None, y_lims=None, color='b.', save_path=None):
        """
        画点列图。
        """
        units = 1
        spot_rms = float(self.rms(ps, units)[0])
        ps = ps.cpu().detach().numpy()[..., :2]
        ps_mean = np.mean(ps, axis=0)  # 质心
        ps = ps - ps_mean[None, ...]  # we now use normalized ps

        fig = plt.figure()
        ax = plt.axes()
        ax.plot(ps[..., 1], ps[..., 0], color)
        plt.gca().set_aspect('equal', adjustable='box')

        if x_lims is not None:
            plt.xlim(*x_lims)
        if y_lims is not None:
            plt.ylim(*y_lims)
        ax.set_aspect(1. / ax.get_data_ratio())
        units_str = '[mm]'
        plt.xlabel('x ' + units_str)
        plt.ylabel('y ' + units_str)
        plt.xticks(np.linspace(x_lims[0], x_lims[1], 11))
        plt.yticks(np.linspace(y_lims[0], y_lims[1], 11))
        # plt.grid(True)

        if save_path is not None:
            fig.savefig(save_path, bbox_inches='tight')
        if show:
            plt.show()
        else:
            plt.close()

        return spot_rms

    def draw_points(self, ax, options, seq=range(3)):
        for surface in self.surfaces:
            points_world = self._generate_points(surface)
            ax.plot(points_world[seq[0]], points_world[seq[1]], points_world[seq[2]], options)

    def generate_mesh(self, name=None, scale=1):
        points = []
        for surface in self.surfaces:
            p, b = self._generate_points(surface, with_boundary=True)
            del b
            points.append(scale * p.T)

        # TODO: 目前仅适用于两个曲面
        x = [points[i][:, 0] for i in range(2)]
        y = [points[i][:, 1] for i in range(2)]
        z = [points[i][:, 2] for i in range(2)]
        tris = [tri.Triangulation(x[i], y[i]) for i in range(2)]
        triangles = [tris[i].triangles for i in range(2)]

        X = np.hstack((x[0], x[1]))
        Y = np.hstack((y[0], y[1]))
        Z = np.hstack((z[0], z[1]))
        T = np.vstack((triangles[0], 1 + triangles[0].max() + triangles[1]))
        mesh = meshio.Mesh(np.stack((X, Y, Z), axis=-1), [("triangle", T)])
        if name is not None:
            mesh.write(name)
        return points

    def plot_setup2D(self, ax=None, fig=None, show=True, color='k', with_sensor=True, index=None):
        surfaces = self.basics.surfaces
        device = self.simulation.device
        materials = self.basics.materials
        aperture_distance = surfaces[self.basics.aper_index].d
        aperture_radius = surfaces[self.basics.aper_index].r
        if ax is None and fig is None:
            fig, ax = plt.subplots(figsize=(20, 15))
        else:
            show = False

        # to world coordinate

        def plot(axx, zz, xx, colors, line_width=3.0):
            p = torch.stack((xx, torch.zeros_like(xx, device=device), zz), dim=1).cpu().detach().numpy()
            axx.plot(p[..., 2], p[..., 0], colors, linewidth=line_width)

        def draw_aperture(axx, d, R, colors):
            N = 3
            APERTURE_WEDGE_LENGTH = 0.05 * R  # [mm]
            APERTURE_WEDGE_HEIGHT = 0.15 * R  # [mm]

            # wedge length
            z_aperture = torch.linspace(d - APERTURE_WEDGE_LENGTH, d + APERTURE_WEDGE_LENGTH, N, device=device)
            x_aperture = -R * torch.ones(N, device=device)
            plot(axx, z_aperture, x_aperture, colors)
            x_aperture = R * torch.ones(N, device=device)
            plot(axx, z_aperture, x_aperture, colors)

            # wedge height
            z_aperture = d * torch.ones(N, device=device)
            x_aperture = torch.linspace(R, R + APERTURE_WEDGE_HEIGHT, N, device=device)
            plot(axx, z_aperture, x_aperture, colors)
            x_aperture = torch.linspace(-R - APERTURE_WEDGE_HEIGHT, -R, N, device=device)
            plot(axx, z_aperture, x_aperture, colors)

        if len(surfaces) == 1:  # if there is only one surface, then it has to be the aperture
            draw_aperture(ax, aperture_distance[index], aperture_radius[index], color)
        else:
            if with_sensor:
                surfaces.append(Aspheric(torch.zeros_like(self.basics.z_sensor), self.basics.z_sensor,
                                         torch.ones_like(self.basics.z_sensor) * self.basics.img_r, device=device))

            draw_aperture(ax, aperture_distance[index], aperture_radius[index], color)
            # 绘制透镜表面
            for i, s in enumerate(surfaces):
                if (i + 1) < len(surfaces) and materials[i].n[index] < 1.0003 and materials[i + 1].n[
                    index] < 1.0003 and i == self.basics.aper_index:
                    continue
                r = torch.linspace(-s.r[index], s.r[index], s.APERTURE_SAMPLING, device=device)  # aperture sampling
                z = torch.zeros_like(r)
                for j in range(len(z)):
                    z[j] = s.surface_with_offset(r[j], 0)[index]
                plot(ax, z, r, color)

            # 绘制边界
            s_prev = []
            for i, s in enumerate(surfaces):
                if materials[i].n[index] < 1.0003:  # 空气
                    s_prev = s
                else:
                    r_prev = s_prev.r[index]
                    r = s.r[index]
                    sag_prev = s_prev.surface_with_offset(r_prev, 0.0)[index].squeeze(0)
                    sag = s.surface_with_offset(r, 0.0)[index].squeeze(0)
                    z = torch.stack((sag_prev, sag))
                    x = torch.Tensor([max(r_prev, r), max(r_prev, r)]).to(device)
                    plot(ax, z, x, color)
                    plot(ax, z, -x, color)
                    if r > r_prev:
                        z = torch.stack((sag_prev, sag_prev))
                        x = torch.Tensor([r_prev, r]).to(device)
                        plot(ax, z, x, color)
                        plot(ax, z, -x, color)
                    else:
                        z = torch.stack((sag, sag))
                        x = torch.Tensor([r, r_prev]).to(device)
                        plot(ax, z, x, color)
                        plot(ax, z, -x, color)
                    s_prev = s

            # 移除传感器平面
            if with_sensor:
                surfaces.pop()

        plt.gca().set_aspect('equal', adjustable='box')
        plt.xlabel('z [mm]')
        plt.ylabel('r [mm]')
        plt.title("Layout 2D")
        # show = True
        if show:
            plt.show()
        return ax, fig

    def plot_setup2D_with_trace_single(self, views, wavelength, M=11):
        colors_list = 'bgrymckbgrymckbgrymck'
        ax, fig = self.plot_setup2D(show=False)
        for i, view in enumerate(views):
            ray = self.sample_ray_2D_common(wavelength, view=view, M=M, R=self.entrance_pos[i][2],
                                            cen=self.entrance_pos[i][0:2])
            oss = self.trace_to_sensor(ray)
            ax, fig = self.plot_ray_traces(oss, ax=ax, fig=fig, color=colors_list[i])
        return ax, fig

    def plot_setup2D_with_trace_whole(self, wavelength, M=11, index=None, keep_invalid=True):
        surfaces = self.basics.surfaces
        colors_list = ['m', 'b', 'c', 'g', 'y', 'r', 'k', '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
                       '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf']
        views = self.order1.fov_samples
        ax, fig = self.plot_setup2D(show=False, index=index)

        for i, view in enumerate(views):
            item = self.order1.enp_xy.clone()
            item[:, i][2:] = item[:, i][2:] - 0.5
            ray = self.sample_ray_2D_common(wavelength, view=view, M=M, pos=item[:, i])
            valid, ray_out, oss = self._trace(ray, record=True)
            # 与传感器平面相交
            t = (self.basics.z_sensor - ray_out.o[2]) / ray_out.d[2]
            p = ray_out(t)
            oss = torch.cat((oss, p.unsqueeze(0)), dim=0)[..., index]

            if surfaces[0].surface(surfaces[0].r, 0.0)[index] < 0:
                oss = oss[1:]
            if not keep_invalid:
                oss = oss[..., valid[..., index]]
            ax, fig = self.plot_ray_traces(oss, ax=ax, fig=fig, color=colors_list[i % len(colors_list)])
        return ax, fig

    # TODO: modify the tracing part to include oss
    def plot_ray_traces(self, oss, ax=None, fig=None, color='b', show=True, p=None, valid_p=None, line_width=2.0):
        """
        Plot all ray traces (oss).
        """
        device = self.simulation.device
        if ax is None and fig is None:
            ax, fig = self.plot_setup2D(show=False)
        else:
            show = False
        for i in range(oss.size(-1)):
            os = oss[..., i].T
            x = os[0]
            z = os[2]

            # to world coordinate
            o = torch.stack((x, torch.zeros_like(x, device=device), z), dim=0).cpu().detach().numpy()
            z = o[2].flatten()
            x = o[0].flatten()

            if p is not None and valid_p is not None:
                if valid_p[i]:
                    x = np.append(x, p[i, 0])
                    z = np.append(z, p[i, 2])

            ax.plot(z, x, color, linewidth=line_width)

        if show:
            plt.show()
        else:
            plt.close()
        return ax, fig

    def calc_RMS(self, ray=None, calc_cen=False):
        valid, ray_out = self._trace(ray)
        # 与传感器平面相交
        t = (self.basics.z_sensor - ray_out.o[2]) / ray_out.d[2]
        p_img = ray_out(t)
        # 通过RMS直径的1.5倍(经验值)作为psf范围
        RMS, p_cen = self.rms(p_img, valid=valid)
        if calc_cen:
            return RMS, p_cen
        else:
            return RMS

    @staticmethod
    def rms(ps, valid=None, ceo=False, mode='3D'):
        if mode == '2D':
            valid_x = valid.clone()
            ps_x = ps[0]
            valid_x[ps_x == 0] = False
            ps_x[~valid_x] = 0
            ps_mean = ps_x.sum(dim=0) / valid_x.sum(dim=0)
            ps_x = ps_x - ps_mean
            ps_x[~valid_x] = 0
            result_x = torch.sqrt(torch.sum(ps_x ** 2, dim=0) / valid_x.sum(dim=0))

            valid_y = valid.clone()
            ps_y = ps[1]
            valid_y[ps_y == 0] = False
            ps_y[~valid_y] = 0
            result_y = torch.sqrt(torch.sum(ps_y ** 2, dim=0) / valid_y.sum(dim=0))
            result = result_y + result_x
        else:
            valid_all = torch.stack((valid, valid, valid), dim=0)
            ps[~valid_all] = 0
            ps_xy = ps[:2]
            ps_mean = (ps_xy.sum(dim=1) / valid.sum(dim=0))
            ps_cen = ps_xy - ps_mean.unsqueeze(1)
            ps_cen[~valid_all[:2]] = 0  # we now use normalized ps
            result = torch.sqrt(torch.sum(ps_cen ** 2, dim=1).sum(dim=0) / valid.sum(dim=0))
        result[torch.isnan(result)] = 1e02
        return result, ps_mean[0]

    def calc_effl(self, wavelength=588.0, approx=False):
        device = self.simulation.device
        size_pop = self.simulation.b_size
        # 主光线与边缘光线在第一面的坐标
        o = torch.zeros(3, 1, size_pop).to(device)
        d = torch.zeros(3, 1, size_pop).to(device)
        o[0] = 1e-10
        d[2] = 1
        # 生成相应光线
        ray = Ray(o, d, wavelength)
        # 输出光线，第一根为主光线，第二根为边缘光线
        valid, ray_out = self._trace(ray, record=False)
        if not valid.any():
            raise Exception('effl ray trace is wrong!')
        o_out = ray_out.o
        d_out = ray_out.d
        t = (0 - o_out[0]) / d_out[0]
        z_sensor = o_out[2] + t * d_out[2]
        t = (1e-10 - o_out[0]) / d_out[0]
        z_main = o_out[2] + t * d_out[2]
        # if approx:
        #     self.basics.z_sensor = z_sensor.squeeze(0)  # 更正位置
        # else:
        #     self.basics.z_sensor = (z_sensor + self.basics.defocus).squeeze(0)

        self.basics.z_sensor = (self.basics.surfaces[-1].d + self.basics.defocus).squeeze(0)
        # 实验
        exp_z_sensor = torch.Tensor(self.basics.exp_z_sensor).to(device)
        n = len(exp_z_sensor)
        self.basics.z_sensor[:n] = self.basics.surfaces[-1].d[:n] + exp_z_sensor

        effl = z_sensor - z_main
        return effl.squeeze(0)

    def calc_max_aper(self, wavelength=588.0, resume=True, M=8):
        surfaces = self.basics.surfaces
        device = self.simulation.device
        aperture_index = self.basics.aper_index
        size_pop = self.simulation.b_size
        if resume:
            for i in range(len(surfaces) - 1):
                item = (1 + self.basics.surfaces[i].k) * (self.basics.surfaces[i].c ** 2)
                item[item <= 0] = 1e-6

                surfaces[i].r = (1 / item) ** 0.5
                surfaces[i].r[surfaces[i].r > self.basics.MAX_R] = self.basics.MAX_R
        self.order1.effl = self.calc_effl(wavelength=wavelength)

        self.order1.enpd = (self.order1.effl / self.basics.min_F_num).abs()

        if self.constraint.effl is not None:
            self.order1.enpd[(self.order1.effl > self.constraint.effl[1])] = (self.constraint.effl[1] / self.basics.min_F_num)
            self.order1.enpd[(self.order1.effl < self.constraint.effl[0])] = (self.constraint.effl[0] / self.basics.min_F_num)
        # 孔阑中心反向追迹，得到入瞳位置
        if aperture_index == 0:
            enpp = surfaces[0].d
            self.order1.enpp = enpp
            self.basics.valid_idx[self.order1.effl <= 0] = False
            return self.order1.enpd / 2
        else:
            o = torch.zeros(3, 1, size_pop).to(device)
            d = torch.zeros(3, 1, size_pop).to(device)
            o[2] = surfaces[aperture_index - 1].d
            o[0] = 1e-10
            d[0] = 1e-10
            d[2] = surfaces[aperture_index - 1].d - surfaces[aperture_index].d
            ray = Ray(o, d / d.square().sum(dim=0).sqrt(), wavelength)
            valid, ray_out = self._trace(ray, stop_ind=aperture_index, record=False)
            if not valid.any():
                raise Exception('ray trace is wrong!')
            o_out = ray_out.o
            d_out = ray_out.d
            enpp = (o_out[2] + (0 - o_out[0]) / d_out[0] * d_out[2]).squeeze(0)
            enpp[torch.isnan(enpp)] = 1  # TODO:这行代码很重要
            self.order1.enpp = enpp
            # 正向追迹得到孔阑半径
            first_x = ((self.basics.z_object - enpp) / self.basics.z_object) * (self.order1.enpd / 2)
            first_x[torch.isnan(first_x)] = 1
            first_x[first_x > self.basics.MAX_R - 2] = self.basics.MAX_R - 2
            o = torch.zeros(3, M, size_pop).to(device)
            d = torch.zeros(3, M, size_pop).to(device)

            o[0] = first_x.unsqueeze(0) * torch.linspace(0.7, 1, M).unsqueeze(1).to(device)
            d[0] = first_x.unsqueeze(0) * torch.linspace(0.7, 1, M).unsqueeze(1).to(device)
            d[2] = -self.basics.z_object
            ray = Ray(o, d / d.square().sum(dim=0).sqrt(), wavelength)
            valid, ray_out = self._trace(ray, stop_ind=aperture_index, record=False)
            if not valid.any():
                raise Exception('ray trace is wrong!')
            self.basics.valid_idx[self.order1.effl <= 0] = False
            return ray_out.o[0].abs().max(dim=0).values

    def calc_max_fov(self, wavelength=588.0, M=1001, resume=False, r_ex=0.2, min_fov=5):
        # 运行时间计算
        surfaces = self.basics.surfaces
        device = self.simulation.device
        aperture_index = self.basics.aper_index
        img_r = self.basics.img_r
        size_pop = self.simulation.b_size
        if resume:
            for i in range(len(surfaces) - 1):
                if i != aperture_index:
                    item = (1 + self.basics.surfaces[i].k) * (self.basics.surfaces[i].c ** 2)
                    item[item <= 0] = 1e-6
                    surfaces[i].r = (1 / item) ** 0.5
                    surfaces[i].r[surfaces[i].r > self.basics.MAX_R] = self.basics.MAX_R
        sag = surfaces[-1].surface(surfaces[-1].r, 0.0)
        r = surfaces[-1].r
        d = surfaces[-1].d
        d_target = d + sag
        R1 = -(r + (r - img_r) * sag / (self.basics.z_sensor - d_target))
        R1[R1 > -r * (1 - r_ex)] = (-r * (1 - r_ex))[R1 > -r * (1 - r_ex)]
        R1[R1 < -r * (1 + r_ex)] = (-r * (1 + r_ex))[R1 < -r * (1 + r_ex)]
        R2 = r + (r + img_r) * sag / (self.basics.z_sensor - d_target)
        R2[R2 > r * (1 - r_ex)] = (r * (1 - r_ex))[R2 > r * (1 - r_ex)]
        R2[R2 < r * (1 + r_ex)] = (r * (1 + r_ex))[R2 < r * (1 + r_ex)]
        o = torch.zeros(3, M, size_pop).to(device)
        origin = torch.zeros(3, M, size_pop).to(device)
        origin[0] = -img_r
        origin[2] = self.basics.z_sensor
        o[2] = surfaces[-1].d

        o[0] = R1.unsqueeze(0) + (R2 - R1).unsqueeze(0) / (M - 1) * torch.linspace(0, M - 1, M).to(device).unsqueeze(1)
        d = o - origin
        ray = Ray(o, d / d.square().sum(dim=0).sqrt(), wavelength)
        valid, ray_final = self._trace(ray, record=False)
        if not valid.any():
            raise Exception('ray trace is wrong!')
        t_img = (self.basics.z_object - ray_final.o[2]) / ray_final.d[2]
        p_img = ray_final(t_img)
        p_img[0][~valid] = 0
        # 严格一点，将valid少一点的和视场角太小的也置为false
        item_fov = (torch.arctan(
            p_img[0].sum(dim=0) / valid.sum(dim=0) / (self.order1.enpp - self.basics.z_object))) / torch.pi * 180
        self.basics.valid_idx[(item_fov < min_fov) & (valid.sum(dim=0) < (M * 0.05))] = False
        fov_max = item_fov[self.basics.valid_idx]
        # 开始re_valid的地方
        self.re_valid_func(self.basics.valid_idx)

        return fov_max.abs()

    def re_valid_func(self, valid_index):

        surfaces = self.basics.surfaces
        materials = self.basics.materials
        for i in range(len(surfaces)):
            surface = surfaces[i]
            surface.c = surface.c[valid_index]
            surface.d = surface.d[valid_index]
            surface.r = surface.r[valid_index]
            surface.k = surface.k[valid_index]
            if surface.ai is not None:
                surface.ai = surface.ai[:, valid_index]
        for i in range(len(materials)):
            mater = materials[i]
            mater.n = mater.n[valid_index]
            mater.V = mater.V[valid_index]
            if mater.A is not None:
                mater.A = mater.A[valid_index]
            if mater.B is not None:
                mater.B = mater.B[valid_index]
        self.order1.enpp = self.order1.enpp[valid_index]
        self.order1.effl = self.order1.effl[valid_index]
        self.basics.z_sensor = self.basics.z_sensor[valid_index]
        if self.order1.enp_xy is not None:
            self.order1.enp_xy = self.order1.enp_xy[..., valid_index]
        if self.order1.vignetting_factors is not None:
            self.order1.vignetting_factors = self.order1.vignetting_factors[..., valid_index]
        if self.order1.fov_samples is not None:
            self.order1.fov_samples = self.order1.fov_samples[..., valid_index]
        if self.order1.fov_max is not None:
            self.order1.fov_max = self.order1.fov_max[..., valid_index]
        if self.order1.aperture_max is not None:
            self.order1.aperture_max = self.order1.aperture_max[..., valid_index]
        if self.order1.aper_flag is not None:
            self.order1.aper_flag = self.order1.aper_flag[..., valid_index]

    def re_init(self):
        if self.order1.effl is not None:
            self.order1.effl = None
        if self.order1.enpp is not None:
            self.order1.enpp = None
        if self.order1.enp_xy is not None:
            self.order1.enp_xy = None
        if self.order1.vignetting_factors is not None:
            self.order1.vignetting_factors = None
        if self.order1.fov_samples is not None:
            self.order1.fov_samples = None
        if self.order1.fov_max is not None:
            self.order1.fov_max = None
        if self.order1.aper_flag is not None:
            self.order1.aper_flag = None
        if self.basics.distort_all is not None:
            self.basics.distort_all = []

    def resize_lens(self, wavelength=588.0, view=None, M=1001, vignetting=1, re_valid=True, r_ex=0.3, valid_rate=0.05):
        size_pop = self.basics.valid_idx.sum()
        radians = view / 180 * torch.pi
        surfaces = self.basics.surfaces
        device = self.simulation.device
        aperture_index = self.basics.aper_index
        self.basics.valid_idx_now = torch.ones(self.basics.valid_idx.sum()).to(device).bool()
        R = surfaces[0].r  # [mm]
        sag = (torch.tan(radians) * surfaces[0].surface(surfaces[0].r, 0.0)).abs()
        sag[sag > R * r_ex] = (R * r_ex)[sag > R * r_ex]
        R1 = -R - sag
        R2 = R + sag
        o = torch.zeros(3, M, size_pop).to(device)
        origin = torch.zeros(3, M, size_pop).to(device)
        o[0] = R1.unsqueeze(0) + (R2 - R1).unsqueeze(0) / (M - 1) * torch.linspace(0, M - 1, M).to(device).unsqueeze(1)
        origin[0] = (self.order1.enpp - self.basics.z_object) * torch.tan(radians)
        origin[2] = self.basics.z_object
        d = o - origin
        ray = Ray(o, d / d.square().sum(dim=0).sqrt(), wavelength)
        valid, _, oss = self._trace(ray, record=True)
        if not valid.any():
            raise Exception('ray trace is wrong!')
        self.basics.valid_idx_now = self.basics.valid_idx_now & (valid.sum(dim=0) > (M * valid_rate))
        self.basics.valid_idx[self.basics.valid_idx.clone()] = self.basics.valid_idx_now.clone()
        valid_index = self.basics.valid_idx_now
        if re_valid:
            oss = oss[..., valid_index]
            self.re_valid_func(valid_index)

        aper_p = oss[aperture_index + 1, 0]
        item_valid = (((aper_p - surfaces[aperture_index].r * vignetting) < 0) & (
                (aper_p + surfaces[aperture_index].r * vignetting) > 0)) & valid[..., valid_index]
        for i in range(len(surfaces)):
            if i != aperture_index:
                p1 = oss[i + 1, 0].abs()
                p1[~item_valid] = 0
                surfaces[i].r = p1.max(dim=0).values + 0.1

    def calc_fov_samples(self, fov_max, wave_main_RGB, non_uniform=False):
        device = self.simulation.device
        # if non_uniform:
        #     views_pre = np.degrees(
        #         np.arctan(math.tan(math.radians(fov_max)) * np.linspace(0, 1, self.simulation.fov_num * 5)))
        #     RMS = np.zeros_like(views_pre)
        #     for i, fov in enumerate(views_pre):
        #         RMS[i] = self.calc_RMS(wavelength=wave_main_RGB[1], view=fov)
        #     RMS_diff = abs(np.diff(RMS))
        #     item1 = np.cumsum(RMS_diff) / RMS_diff.sum()
        #     item2 = np.linspace(0, 1, self.simulation.fov_num)
        #     views_pos = np.zeros_like(item2)
        #     for i, pos in enumerate(item2):
        #         views_pos[i] = abs(item1 - pos).argmin()
        #     views_pos = views_pos / (len(item1) - 1)
        #     views = np.degrees(np.arctan(math.tan(math.radians(fov_max)) * views_pos))
        # # 均匀采样用这个
        # else:
        views = torch.arctan(torch.linspace(0, 1, self.simulation.fov_num).unsqueeze(1).to(device) * torch.tan(
            fov_max / 180 * torch.pi).unsqueeze(0)) / torch.pi * 180
        views_pos = torch.linspace(0, 1, self.simulation.fov_num).to(device)
        return views, views_pos

    # 在透镜前，计算得到近轴放大率，注意使用64位
    def calc_room_rate(self, wavelength=588.0, view=0.0):
        surfaces = self.basics.surfaces
        device = self.simulation.device
        angle = np.radians(view)
        if angle == 0:
            angle += 1e-8
        # 主光线与边缘光线在第一面的坐标
        first_x = torch.Tensor([1e-10, 1e-10]).to(device).double()
        ones = torch.ones_like(first_x)
        zeros = torch.zeros_like(first_x)
        # o为在孔阑面的空间坐标
        o = torch.stack((first_x, zeros, zeros))
        # origin为在物面的坐标
        obj_x = torch.Tensor([0, 1e-10]).to(device).double()
        origin = torch.stack([obj_x, zeros, self.basics.z_object * ones])
        d = o - origin
        d = torch.div(d, d.norm(2, 0))
        d = d.T
        o = o.T
        # 生成相应光线
        ray = Ray(o, d, wavelength)
        # 输出光线，第一根为主光线，第二根为边缘光线
        _, ray_out = self._trace(ray, stop_ind=None, record=False)
        # 近轴放大率计算
        # 通过主光线求得近轴像位置
        o_out = ray_out.o[0]
        d_out = ray_out.d[0]
        t = (0 - o_out[0]) / d_out[0]
        d_sensor = o_out[2] + t * d_out[2]
        if self.basics.z_sensor is None:
            self.basics.z_sensor = d_sensor  # 更正位置
        # 通过近轴光线求得近轴像高度
        o_out = ray_out.o[1]
        d_out = ray_out.d[1]
        t = (d_sensor - o_out[2]) / d_out[2]
        img_r = o_out[0] + t * d_out[0]
        zoom_rate_pari = img_r / 1e-10
        return zoom_rate_pari.float()

    def calc_exit_pupil(self):
        # 孔阑中心反向追迹，得到入瞳位置
        surfaces = self.basics.surfaces
        device = self.simulation.device
        aperture_index = self.basics.aper_index
        wavelength = self.order1.wave_data["main"]
        if aperture_index >= len(surfaces) - 1:
            expp = surfaces[aperture_index].d
        else:
            o = torch.Tensor([1e-10, 0, surfaces[aperture_index + 1].d]).unsqueeze(0).to(device).double()
            d = torch.Tensor([1e-10, 0, surfaces[aperture_index + 1].d - surfaces[aperture_index].d]).unsqueeze(0).to(
                device).double()
            ray = Ray(o, d / d.square().sum().sqrt(), wavelength)
            valid, ray_out = self._trace(ray, record=False)
            if not valid[0]:
                raise Exception('ray trace is wrong!')
            o_out = ray_out.o[0]
            d_out = ray_out.d[0]
            expp = (o_out[2] + (0 - o_out[0]) / d_out[0] * d_out[2]).item()
        self.order1.expp = expp

        # ------------------------------------------------------------------------------------
        # 应用程序
        # ------------------------------------------------------------------------------------

    def calc_entrance_pupil_all(self, wavelength=588.0, views=None, M=32, cen=None, R=None, vignetting=1
                                , valid_rate=0.01, re_valid=True):
        M2 = M ** 2
        surfaces = self.basics.surfaces
        aperture_index = self.basics.aper_index
        device = self.simulation.device
        pos = torch.zeros(4, len(R)).to(device)
        pos[2:4] = R
        size_pop_now = self.basics.valid_idx.sum()
        ray_o = torch.zeros(3, M2 * self.simulation.fov_num, size_pop_now).to(device)
        ray_d = torch.zeros(3, M2 * self.simulation.fov_num, size_pop_now).to(device)
        for i in range(self.simulation.fov_num):
            fov = views[i]
            ray = self.sample_ray_2D_common(wavelength, view=fov, pos=pos, M=M2, mode='x')
            ray_o[:, i * M2:(i + 1) * M2] = ray.o
            ray_d[:, i * M2:(i + 1) * M2] = ray.d

        # for i in range(self.simulation.fov_num):
        #     fov = views[i]
        #     ray = self.sample_ray_2D_common(wavelength, view=fov, pos=pos, M=M2, mode='y')
        #     ray_o[:, (i + self.simulation.fov_num) * M2:(i + 1 + self.simulation.fov_num) * M2] = ray.o
        #     ray_d[:, (i + self.simulation.fov_num) * M2:(i + 1 + self.simulation.fov_num) * M2] = ray.d

        ray_all = Ray(ray_o, ray_d, wavelength)
        valid_all, ray_final_all, oss_all = self._trace(ray_all, record=True)

        for i in range(self.simulation.fov_num):
            valid = valid_all[i * M2:(i + 1) * M2]
            self.basics.valid_idx_now = self.basics.valid_idx_now & (valid.sum(dim=0) > (M2 * valid_rate))
        if self.basics.valid_idx.sum() == len(self.basics.valid_idx_now):
            self.basics.valid_idx[self.basics.valid_idx.clone()] = self.basics.valid_idx_now.clone()
        else:
            self.basics.valid_idx[:] = True
            self.basics.valid_idx_now[:] = True
        valid_index = self.basics.valid_idx_now
        if re_valid:
            self.re_valid_func(valid_index)

        enp_xy = torch.zeros(4, views.size(0), valid_index.sum()).to(device)
        vignetting_factors = torch.zeros(views.size(0), valid_index.sum()).to(device)
        # resize
        item_oss = oss_all[..., self.basics.valid_idx_now]
        aper_p = item_oss[aperture_index + 1, 0]
        item_valid = (((aper_p - surfaces[aperture_index].r * vignetting) < 0) & (
                (aper_p + surfaces[aperture_index].r * vignetting) > 0)) & valid_all[..., valid_index]

        # 0视场角光线没有填充孔阑的也视为无效
        aper_p[~valid_all[..., valid_index]] = 0
        self.order1.aper_flag = (aper_p[:M * M].abs() - surfaces[aperture_index].r).abs().min(dim=0).values

        item_edge_fov_up = surfaces[aperture_index].r * 0.8 - aper_p[(self.simulation.fov_num - 1) * M * M:].max(dim=0).values
        item_edge_fov_up[item_edge_fov_up < 0] = 0
        self.order1.aper_flag = self.order1.aper_flag + item_edge_fov_up
        item_edge_fov_down = aper_p[(self.simulation.fov_num - 1) * M * M:].min(dim=0).values + surfaces[aperture_index].r * 0.8
        item_edge_fov_down[item_edge_fov_down < 0] = 0
        self.order1.aper_flag = self.order1.aper_flag + item_edge_fov_down

        # # 应对出现断续的情况
        # for i in range(self.simulation.fov_num):
        # valid_item = item_valid[i * (M * M):(i + 1) * (M * M)]

        for i in range(len(surfaces)):
            if i != aperture_index:
                p1 = item_oss[i + 1, 0].abs()
                p1[~item_valid] = 0
                p1[p1 > self.basics.MAX_R] = self.basics.MAX_R
                surfaces[i].r = p1.max(dim=0).values + 0.1

        for i in range(self.simulation.fov_num):
            # valid = valid_all[i * (M * M):(i + 1) * (M * M), self.basics.valid_idx_now]
            valid = item_valid[i * (M * M):(i + 1) * (M * M)]

            ray_d = ray_final_all.d[:, i * (M * M):(i + 1) * (M * M), self.basics.valid_idx_now]
            oss = oss_all[:, :, i * (M * M):(i + 1) * (M * M), self.basics.valid_idx_now]
            first_px = oss[0, 0]

            first_px[~valid] = 10e6

            x1 = first_px.min(dim=0).values

            first_px[~valid] = -10e6

            x2 = first_px.max(dim=0).values

            ray_d_z = ray_d[2]
            ray_d_xyz = (ray_d[0].square() + ray_d[1].square() + ray_d_z.square()).sqrt()
            item_cos = ray_d_z / ray_d_xyz
            item_cos[~valid] = 0
            cos_img_angle = (item_cos ** 4).sum(dim=0) / valid.sum(dim=0)
            enp_xy[:, i] = torch.stack(((x1 + x2) / 2, torch.zeros_like(x1), (x2 - x1) / 2 + 0.5, (x2 - x1) / 2 + 0.5), dim=0)
            vignetting_factors[i] = valid.sum(dim=0) * cos_img_angle
        return enp_xy, vignetting_factors

    def calc_entrance_pupil(self, wavelength=588.0, view=None, M=32, cen=None, R=None):
        device = self.simulation.device
        pos = torch.zeros(4, len(R)).to(device)
        pos[2:4] = R
        ray = self.sample_ray_2D_common(wavelength, view=view, pos=pos, M=M)
        valid, ray_final, oss = self._trace(ray, record=True)
        self.basics.valid_idx_now = self.basics.valid_idx_now & valid.sum(dim=0).bool()
        ray_d = ray_final.d
        first_px = oss[0, 0]
        first_py = oss[0, 1]
        first_px[~valid] = 10e6
        first_py[~valid] = 10e6
        x1 = first_px.min(dim=0).values
        y1 = first_py.min(dim=0).values
        first_px[~valid] = -10e6
        first_py[~valid] = -10e6
        x2 = first_px.max(dim=0).values
        y2 = first_py.max(dim=0).values
        ray_d_z = ray_d[2]
        ray_d_xyz = (ray_d[0].square() + ray_d[1].square() + ray_d_z.square()).sqrt()
        cos_img_angle = (ray_d_z / ray_d_xyz).mean(dim=0)
        return torch.stack(((x1 + x2) / 2, (y1 + y2) / 2, (x2 - x1) / 2, (y2 - y1) / 2), dim=0), valid.sum(dim=0) * (
                cos_img_angle ** 4)

    def calc_enp_all_fov(self, wavelength=588.0, r_ex=0.4):
        views = self.order1.fov_samples
        surfaces = self.basics.surfaces
        device = self.simulation.device
        R = surfaces[0].r  # [mm]
        # vignetting_factors = torch.zeros_like(views)
        # enp_xy = torch.zeros(4, views.size(0), views.size(1)).to(device)
        sag = (torch.tan(self.order1.fov_max / 180 * torch.pi) * surfaces[0].surface(R, 0.0)).abs()
        sag[sag > R * r_ex] = (R * r_ex)[sag > R * r_ex]
        R = sag + R
        self.basics.valid_idx_now = torch.ones(self.basics.valid_idx.sum()).to(device).bool()
        enp_xy, vignetting_factors = self.calc_entrance_pupil_all(
            wavelength=wavelength, views=views, R=R, M=self.simulation.enp_num)

        # 渐晕因子归一化(包含了相对照度的影响）
        vignetting_factors = vignetting_factors / vignetting_factors.max(dim=0).values
        return enp_xy, vignetting_factors

    def sample_ray_common(self, wavelength, view=None, M=15, sampling='grid', pos=None, flag_quick=True):
        surfaces = self.basics.surfaces
        device = self.simulation.device
        angle = view / 180 * torch.pi  # 用弧度值代替度值数组
        cen_x = pos[0]
        cen_y = pos[1]
        R_x = pos[2]
        R_y = pos[3]
        x = torch.zeros(M * M, pos.size(1)).to(device)
        y = torch.zeros(M * M, pos.size(1)).to(device)
        # R最大输入半径，即采样范围，这里为什么要加上倾斜的那一部分？应该是默认第一面作为孔径光阑
        size_pop_now = self.basics.valid_idx.sum()
        o = torch.zeros(3, M * M, size_pop_now).to(device)
        origin = torch.zeros(3, M * M, size_pop_now).to(device)

        if sampling == 'grid':
            # t1 = time.time()
            x_index = (torch.linspace(0, M - 1, M).to(device)).expand(M, M).T.flatten().unsqueeze(1)
            y_index = (torch.linspace(0, M - 1, M).to(device)).expand(M, M).flatten().unsqueeze(1)
            x = cen_x - R_x + 2 * R_x / (M - 1) * x_index
            y = cen_y - R_y + 2 * R_y / (M - 1) * y_index
            o[0] = x
            o[1] = y
        elif sampling == 'cross':
            M_1 = (M ** 2) // 2
            M_2 = M ** 2 - M_1
            if flag_quick:
                y = cen_y + R_y / (M_2 - 1) * torch.linspace(0, M_2 - 1, M_2).to(device).unsqueeze(1)
            else:
                y = cen_y - R_y + 2 * R_y / (M_2 - 1) * torch.linspace(0, M_2 - 1, M_2).to(device).unsqueeze(1)
            x = cen_x - R_x + 2 * R_x / (M_1 - 1) * torch.linspace(0, M_1 - 1, M_1).to(device).unsqueeze(1)
            o[0, :M_1] = x
            o[1, M_1:] = y
        # 主光线与边缘光线在第一面的坐标

        origin[0] = (self.order1.enpp - self.basics.z_object) * torch.tan(angle)
        origin[2] = self.basics.z_object
        # 得到光线方向矢量d，2D方向改为3D方向，在x方向采样得到psf
        d = o - origin
        return Ray(o, d / d.square().sum(dim=0).sqrt(), wavelength)  # 这里返回的是一个光线类

    def sample_ray_2D_common(self, wavelength, view=None, M=15, pos=None, mode='x'):
        if pos.dim() < 2:
            pos = pos.unsqueeze(1)
        device = self.simulation.device
        angle = view / 180 * torch.pi  # 用弧度值代替度值数组
        cen_x = pos[0].unsqueeze(0)
        R_x = pos[2].unsqueeze(0)
        x = cen_x - R_x + 2 * R_x / (M - 1) * torch.linspace(0, M - 1, M).to(device).unsqueeze(1)
        size_pop_now = x.size(1)
        # 主光线与边缘光线在第一面的坐标
        o = torch.zeros(3, M, size_pop_now).to(device)
        origin = torch.zeros(3, M, size_pop_now).to(device)
        if mode == 'x':
            o[0] = x
        else:
            o[1] = x
        enpp_item = self.order1.enpp
        origin[0] = (enpp_item - self.basics.z_object) * torch.tan(angle)
        origin[2] = self.basics.z_object
        # 得到光线方向矢量d，2D方向改为3D方向，在x方向采样得到psf
        d = o - origin
        return Ray(o, d / d.square().sum(dim=0).sqrt(), wavelength)

    def write_optics_data(self, acc_idx, save_path='optics_data.txt', round_num=4):
        surfaces = self.basics.surfaces
        materials = self.basics.materials
        num = 0
        if os.path.exists(save_path):
            with open(save_path, 'r', encoding='utf-8') as f:  # 使用with open()新建对象f
                contents = f.readlines()
                if len(contents) == 0:
                    num = 0
                else:
                    j = len(contents)
                    while j > 0:
                        if contents[j - 1][:3] == 'num':
                            num = int(contents[j - 1][4:-1]) + 1
                            break
                        j = j - 1
            f.close()
        with open(save_path, 'a', encoding='utf-8') as f:  # 使用with open()新建对象f
            for count in range(len(acc_idx)):
                now_idx = self.basics.valid_idx[:acc_idx[count]].sum()
                f.write('num:' + str(num) + '\n')
                fit_now = self.basics.fit_all[self.basics.valid_idx][now_idx]
                item = "order   radius     thickness     n     V     r     conic     ai      fit={fit}    aper_idx={x}\n".format(
                    fit=fit_now.item(), x=self.basics.aper_index)
                for i in range(len(surfaces)):
                    if i < len(surfaces) - 1:
                        thi = surfaces[i + 1].d[now_idx].item() - surfaces[i].d[now_idx].item()
                    else:
                        thi = self.basics.z_sensor[now_idx].item() - surfaces[i].d[now_idx].item()
                    if i == self.basics.aper_index:
                        c_r = math.inf
                    else:
                        c_r = round(1 / surfaces[i].c[now_idx].item(), round_num)
                    item += "{num}      {c_r}       {thi}       {n}       {V}       {r}       {k}      " \
                        .format(num=i, c_r=c_r, thi=round(thi, round_num),
                                k=round(surfaces[i].k[now_idx].item(), round_num),
                                r=round(surfaces[i].r[now_idx].item(), round_num),
                                n=round(materials[i + 1].n[now_idx].item(), round_num),
                                V=round(materials[i + 1].V[now_idx].item(), round_num))
                    if surfaces[i].ai is not None:
                        ai = surfaces[i].ai[..., now_idx]
                        for ii in range(len(ai)):
                            item += "{ai} ".format(ai=ai[ii].item())
                    item += "\n"
                item += 'end\n\n'
                f.write(item)
                num = num + 1
        f.close()

    @staticmethod
    def read_data(read_path, device, iteration=8):
        surfaces = []
        materials = [Material('air')]
        with open(read_path, 'r', encoding='utf-8') as f:  # 使用with open()新建对象f
            contents = f.readlines()
            for i in range(len(contents)):
                if contents[i] == 'iteration:{num}\n'.format(num=iteration):
                    while contents[i + 2] != 'end\n':
                        content = str.split(contents[i + 2])
                        if len(content) <= 7:
                            surfaces.append(
                                Aspheric(float(content[4]), float(content[1]), c=float(content[2]), k=float(content[3]),
                                         device=device))
                        else:
                            ai = []
                            for ii in range(7, len(content)):
                                ai.append(torch.Tensor([float(content[ii])])[0].to(device))
                            surfaces.append(
                                Aspheric(float(content[4]), float(content[1]), c=float(content[2]), k=float(content[3]),
                                         ai=ai, device=device))
                        materials.append(Material(data=[float(content[5]), float(content[6])]))
                        i += 1
                    break
        f.close()
        return surfaces, materials

    def init_sel(self, div_rate=0.1, draw=True, max_num=200):
        device = self.simulation.device
        contents = []
        aper = []
        data = []
        fit = []
        idx = []
        for item in range(len(self.path.save_root) - 1):
            read_path = self.path.save_root[item]
            with open(read_path, 'r', encoding='utf-8') as f:  # 使用with open()新建对象f
                contents = contents + f.readlines()
            f.close()

        i = 0
        while i < len(contents):
            if contents[i][:3] == 'num':
                idx.append(i)
                aper_now = int(str.split(contents[i + 1])[-1][9:])
                aper.append(aper_now)
                fit.append(float(str.split(contents[i + 1])[-2][4:]))
                i += 2
                pre_data = []
                while contents[i] != 'end\n':
                    content = np.array(str.split(contents[i]))
                    content[content == 'inf'] = math.inf
                    pre_data.append(content)
                    i += 1
                pre_data = np.array(pre_data).astype(float)
                surface_num = pre_data.shape[0]
                c = pre_data[:, 1]
                d = pre_data[:, 2]
                n = pre_data[:, 3]
                V = pre_data[:, 4]
                mater_idx = n[:surface_num - 1] > 1.003
                c2 = ((1 / c[c < math.inf]) - self.constraint.c[0]) / (self.constraint.c[1] - self.constraint.c[0])
                d2 = np.zeros(surface_num - 1)
                d2[mater_idx] = (d[:surface_num - 1][mater_idx] - self.constraint.thi_glass_cen[0]) / (
                            self.constraint.thi_glass_cen[1] - self.constraint.thi_glass_cen[0])
                d2[~mater_idx] = (d[:surface_num - 1][~mater_idx] - self.constraint.thi_air_cen[0]) / (
                        self.constraint.thi_air_cen[1] - self.constraint.thi_air_cen[0])
                n2 = (n[:surface_num - 1][mater_idx] - self.constraint.material_n[0]) / (
                            self.constraint.material_n[1] - self.constraint.material_n[0])
                V2 = (V[:surface_num - 1][mater_idx] - self.constraint.material_V[0]) / (
                            self.constraint.material_V[1] - self.constraint.material_V[0])
                data.append(np.array(c2.tolist() + d2.tolist() + n2.tolist() + V2.tolist()))
            i += 1
        row_per = round(len(contents) / len(data))
        fit_sorted_idx = (torch.Tensor(fit).to(device).sort()[1]).detach().cpu().numpy()
        data_pre = np.array(data)
        idx_final = []
        fit_final = []
        data_final = []
        aper_final = []
        for i in range(len(fit_sorted_idx)):
            idx_now = fit_sorted_idx[i]
            data_now = data_pre[idx_now]
            fit_now = fit[idx_now]
            aper_now = aper[idx_now]
            acc_flag = False
            if i == 0:
                acc_flag = True
            else:
                aper_idx = (np.array(aper_final) - aper_now == 0)
                if sum(aper_idx) == 0:
                    acc_flag = True
                elif (np.sqrt(np.sum(np.square(np.array(data_final) - data_now), axis=1)))[aper_idx].min() / (len(data_now) ** 0.5) > div_rate:
                    acc_flag = True
            if acc_flag:
                idx_final.append(idx[idx_now])
                data_final.append(data_now)
                aper_final.append(aper_now)
                fit_final.append(fit_now)
        contents_final = []
        if len(idx_final) > max_num:
            idx_final = idx_final[:max_num]
        for i in range(len(idx_final)):
            idx = idx_final[i]
            item = contents[idx: idx + row_per]
            item[0] = 'num:' + str(i) + '\n'
            for j in range(len(item)):
                contents_final.append(item[j])
        with open(self.path.save_root[-1], 'a', encoding='utf-8') as f:
            for i in range(len(contents_final)):
                f.write(contents_final[i])
        f.close()

    def trace_valid(self, ray):
        """
        追迹光线以查看它们是否与传感器平面相交。
        """
        valid = self._trace(ray)[1]
        return valid

    @staticmethod
    def _refract(wi, n, eta, approx=False):
        """
        Snell's law (surface normal n defined along the positive z axis)
        https://physics.stackexchange.com/a/436252/104805
        """
        n = n
        wi = wi
        eta_ = eta
        cosi = torch.sum(wi * n, dim=0)

        if approx:
            tmp = 1. - eta ** 2 * (1. - cosi)
            valid = tmp > 0.
            wt = tmp * n + eta_ * (wi - cosi * n)
        else:
            cost2 = 1. - (1. - cosi ** 2) * eta ** 2

            # 1. get valid map; 2. zero out invalid points; 3. add eps to avoid NaN grad at cost2==0.
            valid = (cost2 > 0.0001) & (cosi > 0.0001)
            cost2 = torch.clamp(cost2, min=1e-8)
            tmp = torch.sqrt(cost2)

            # here we do not have to do normalization because if both wi and n are normalized,
            # then output is also normalized.
            wt = tmp * n + eta_ * (wi - cosi * n)
        return valid, wt

    def trace_to_sensor(self, ray, record=False):
        """
        光线追迹，使其与传感器平面相交。
        """
        oss = None
        if record:
            valid, ray_out, oss = self._trace(ray, record=record)
        else:
            valid, ray_out = self._trace(ray, record=record)
        # 与传感器平面相交
        t = (self.basics.z_sensor - ray_out.o[2]) / ray_out.d[2]
        p = ray_out(t)
        if record:
            return oss, p
        else:
            return p

    def _trace(self, ray, stop_ind=None, record=False):
        if stop_ind is None:
            stop_ind = len(self.basics.surfaces) - 1  # 如果没有设置是否在哪停下，最后一面作为stop
        is_forward = (ray.d[2] > 0).all()  # 确认光线是否正向传播
        if is_forward:
            return self._forward_tracing(ray, stop_ind, record)
        else:
            return self._backward_tracing(ray, stop_ind, record)

    def _forward_tracing(self, ray, stop_ind, record):
        wavelength = ray.wavelength
        surfaces = self.basics.surfaces
        materials = self.basics.materials
        device = self.simulation.device
        oss = torch.ones(stop_ind + 2, ray.o.shape[0], ray.o.shape[1], ray.o.shape[2]).to(device)
        if record:
            oss[0] = ray.o
        valid = torch.ones(ray.o.shape[1], ray.o.shape[2], device=device).bool()
        for i in range(stop_ind + 1):
            # 两个表面折射率之比
            eta = materials[i].ior(wavelength) / materials[i + 1].ior(wavelength)
            # 光线与透镜表面相交，p为与透镜表面交点，
            valid_o, p = surfaces[i].ray_surface_intersection(ray, valid)
            valid = valid & valid_o
            if not valid.any():
                break
            item2 = p.transpose(0, 2)[valid.transpose(0, 1)]
            # 异常值范围限制，防止计算报错
            p2 = torch.stack((torch.clamp(p[0], min=item2[..., 0].min().item(), max=item2[..., 0].max().item()),
                              torch.clamp(p[1], min=item2[..., 1].min().item(), max=item2[..., 1].max().item()),
                              torch.clamp(p[2], min=item2[..., 2].min().item(), max=item2[..., 2].max().item())),
                             dim=0)
            # 得到透镜表面法线
            n = surfaces[i].normal(p2[0], p2[1])

            if self.diff.loss_raytrace_flag:
                # cos_total_reflection = min(torch.cos(torch.arcsin(1 / eta)), torch.Tensor([1])[0].to(self.device))
                # cos_total_reflection = torch.cos(torch.arcsin(eta))
                # item = (torch.exp(1 + (ray.d * n).sum(dim=0))-1) / (math.e - 1)
                if i != self.basics.aper_index:
                    item = (1 + (ray.d * n).sum(dim=0))
                    item[~valid] = 0
                    item[item < 0.6] = 0
                    self.diff.loss_raytrace = self.diff.loss_raytrace + item.sum(dim=0)
                    self.diff.loss_raytrace_num = self.diff.loss_raytrace_num + valid.sum(dim=0)

            valid_d, d = self._refract(ray.d, -n, eta)
            # 检验有效性
            valid_d[d[2] <= 0] = False
            valid = valid & valid_d
            if not valid.any():
                break
            ray.o = p2
            ray.d = d
            # 更新光线 {o,d}
            if record:
                oss[i + 1] = ray.o
        if len(self.basics.valid_idx) != valid.size(1):
            valid_item = torch.zeros(len(self.basics.valid_idx)).to(device).bool()
            valid_item[self.basics.valid_idx] = (valid.sum(dim=0)).bool()
        else:
            valid_item = (valid.sum(dim=0)).bool()
            self.basics.valid_idx = self.basics.valid_idx & valid_item
        if record:
            return valid, ray, oss
        else:
            return valid, ray

    def _backward_tracing(self, ray, stop_ind, record):
        wavelength = ray.wavelength
        surfaces = self.basics.surfaces
        materials = self.basics.materials
        device = self.simulation.device
        oss = torch.ones(stop_ind + 2, ray.o.shape[0], ray.o.shape[1], ray.o.shape[2]).to(device)
        if record:
            oss[-1] = ray.o
        valid = torch.ones(ray.o.shape[1], ray.o.shape[2], device=device).bool()
        for i in np.flip(range(stop_ind + 1)):
            surface = surfaces[i]
            eta = materials[i + 1].ior(wavelength) / materials[i].ior(wavelength)
            # ray intersecting surface
            valid_o, p = surface.ray_surface_intersection(ray, valid)

            valid = valid & valid_o
            if not valid.any():
                break

            # 异常值范围限制，防止计算报错
            item2 = p.transpose(0, 2)[valid.transpose(0, 1)]
            # 异常值范围限制，防止计算报错
            p2 = torch.stack((torch.clamp(p[0], min=item2[..., 0].min().item(), max=item2[..., 0].max().item()),
                              torch.clamp(p[1], min=item2[..., 1].min().item(), max=item2[..., 1].max().item()),
                              torch.clamp(p[2], min=item2[..., 2].min().item(), max=item2[..., 2].max().item())),
                             dim=0)
            n = surfaces[i].normal(p2[0], p2[1])
            valid_d, d = self._refract(ray.d, n, eta)  # backward: no need to revert the normal
            # check validity
            valid = valid & valid_d
            if not valid.any():
                break
            # update ray {o,d}
            ray.o = p2
            ray.d = d
            if record:
                oss[i] = ray.o
        if len(self.basics.valid_idx) != valid.size(1):
            valid_item = torch.zeros(len(self.basics.valid_idx)).to(device).bool()
            valid_item[self.basics.valid_idx] = (valid.sum(dim=0)).bool()
        else:
            valid_item = (valid.sum(dim=0)).bool()
            self.basics.valid_idx = self.basics.valid_idx & valid_item
        if record:
            return valid, ray, oss
        else:
            return valid, ray


class Surfaces(PrettyPrinter):
    def __init__(self, r, d, is_square=False, device=torch.device('cpu')):
        self.d = d.to(device)
        self.is_square = is_square
        self.r = r.to(device)
        self.device = device
        self.z_con = None

        # 控制光线追迹精度的参数
        self.NEWTONS_MAX_ITER = 10
        self.NEWTONS_TOLERANCE_TIGHT = 500e-6  # in [mm], i.e. 500 [nm] here (up to <10 [nm])
        self.NEWTONS_TOLERANCE_LOOSE = 3000e-6  # in [mm], i.e. 3000 [nm] here (up to <10 [nm])
        self.APERTURE_SAMPLING = 63

    # === 一般方法 (一定不能被覆盖的)
    def surface_with_offset(self, x, y):
        return self.surface(x, y) + self.d

    def normal(self, x, y):
        ds_dxyz = self.surface_derivatives(x, y)
        return normalize(torch.stack(ds_dxyz, dim=0))

    def surface_area(self):
        if self.is_square:
            return self.r ** 2
        else:  # is round
            return math.pi * self.r ** 2

    def mesh(self):
        """
        为当前曲面生成网格。
        """
        x, y = torch.meshgrid(
            torch.linspace(-self.r, self.r, self.APERTURE_SAMPLING, device=self.device),
            torch.linspace(-self.r, self.r, self.APERTURE_SAMPLING, device=self.device),
            indexing='ij'
        )
        valid_map = self.is_valid(torch.stack((x, y), dim=-1))
        return self.surface(x, y) * valid_map

    def sdf_approx(self, p):  # 近似的 SDF
        """
        This function is more computationally efficient than `sdf`.
        - < 0: valid
        """
        if self.is_square:
            return torch.max(torch.abs(p) - self.r, dim=-1)[0]
        else:  # is round
            return (p ** 2).sum(dim=0) - self.r ** 2

    def is_valid(self, p):
        return (self.sdf_approx(p) < 0.0).bool()

    def ray_surface_intersection(self, ray, active=None):
        """
        Returns:
        - p: 交点
        - g: 显式函数
        """
        solution_found, local = self.newtons_method(ray.maxt, ray.o, ray.d)

        valid_o = solution_found & self.is_valid(local[0:2])
        if active is not None:
            valid_o = active & valid_o
        return valid_o, local

    def newtons_method_impl(self, maxt, t0, dx, dy, dz, ox, oy, oz, A, B, C):
        t_delta = torch.zeros_like(oz)
        # 迭代直到相交误差很小
        residual = maxt * torch.ones_like(oz)
        it = 0

        while (torch.abs(residual) > self.NEWTONS_TOLERANCE_TIGHT).any() and (it < self.NEWTONS_MAX_ITER):
            it += 1
            t = t0 + t_delta  # 相加的t0即是在透镜顶点的倍数，t_delta是后面的
            residual, s_derivatives_dot_D = self.surface_and_derivatives_dot_D(
                t, dx, dy, dz, ox, oy, t_delta * dz + self.z_con, A, B, C  # here z = t_delta * dz
            )

            s_derivatives_dot_D[s_derivatives_dot_D.abs() < 1e-12] = 1e-12
            s_derivatives_dot_D[s_derivatives_dot_D.abs() > 1e24] = 1e24
            residual[residual.abs() < 1e-24] = 1e-24
            residual[residual.abs() > 1e12] = 1e12

            t_delta = t_delta - residual / s_derivatives_dot_D
        t = t0 + t_delta
        valid = (torch.abs(residual) < self.NEWTONS_TOLERANCE_LOOSE) & (t <= maxt)
        return t, t_delta, valid

    def newtons_method(self, maxt, o, D, option='explicit'):
        # 牛顿法求光线曲面交点方程的根。
        # 支持两种模式:
        # 
        # 1. 'explicit": 利用 autodiff 实现循环, 而且梯度对于 o, D, and self.parameters 是准确的. 不仅缓慢而且耗费内存.
        # 
        # 2. 'implicit": 这使用隐式层理论实现了循环, 不用autodiff, 然后勾选梯度。更少的内存消耗，遗传算法不涉及梯度所以暂不使用。

        # 计算前常数
        ox, oy, oz = (o[i].clone() for i in range(3))
        dx, dy, dz = (D[i].clone() for i in range(3))
        A = dx ** 2 + dy ** 2
        B = 2 * (dx * ox + dy * oy)
        C = ox ** 2 + oy ** 2

        # initial guess of t
        t0 = (self.d - oz) / dz
        # C2 = (o + t0 * D)[0] ** 2 + (o + t0 * D)[1] ** 2
        item_t0 = (1 / (self.c * (1 + self.k) ** 0.5)).abs() - C ** 0.5
        t0[item_t0 <= 0] = ((item_t0 / (A ** 0.5) * (1 + 1e-2))[item_t0 <= 0]).abs()
        self.z_con = (t0 - (self.d - oz) / dz) * dz

        if option == 'explicit':
            t, t_delta, valid = self.newtons_method_impl(
                maxt, t0, dx, dy, dz, ox, oy, oz, A, B, C
            )
        elif option == 'implicit':
            with torch.no_grad():
                t, t_delta, valid = self.newtons_method_impl(
                    maxt, t0, dx, dy, dz, ox, oy, oz, A, B, C
                )
            s_derivatives_dot_D = self.surface_and_derivatives_dot_D(
                t, dx, dy, dz, ox, oy, t_delta * dz, A, B, C
            )[1]
            t = t0 + t_delta
            residual = (self.g(ox + t * dx, oy + t * dy) + self.h(oz + t * dz) + self.d)
            s_derivatives_dot_D[s_derivatives_dot_D.abs() < 1e-12] = 1e-12
            s_derivatives_dot_D[s_derivatives_dot_D.abs() > 1e24] = 1e24
            residual[residual.abs() < 1e-24] = 1e-24
            residual[residual.abs() > 1e12] = 1e12
            t = t - residual / s_derivatives_dot_D
        else:
            raise Exception('option={} is not available!'.format(option))

        p = o + t * D
        return valid, p

    # === Virtual methods (must be overridden)
    def g(self, x, y):
        raise NotImplementedError()

    def dgd(self, x, y):
        """
        Derivatives of g: (g'x, g'y).
        """
        raise NotImplementedError()

    def h(self, z):
        raise NotImplementedError()

    def dhd(self, z):
        """
        Derivative of h.
        """
        raise NotImplementedError()

    def surface(self, x, y):
        """
        Solve z from h(z) = -g(x,y).
        """
        raise NotImplementedError()

    def reverse(self):
        raise NotImplementedError()

    # === 默认方法 (最好被覆盖)
    def surface_derivatives(self, x, y):
        """
        Returns \nabla f = \nabla (g(x,y) + h(z)) = (dg/dx, dg/dy, dh/dz).
        (Note: this default implementation is not efficient)
        """
        gx, gy = self.dgd(x, y)
        z = self.surface(x, y)
        return gx, gy, self.dhd(z)

    def surface_and_derivatives_dot_D(self, t, dx, dy, dz, ox, oy, z, A, B, C):
        """
        Returns g(x,y)+h(z) and dot((g'x,g'y,h'), (dx,dy,dz)).
        (Note: this default implementation is not efficient)
        """
        x = ox + t * dx
        y = oy + t * dy
        s = self.g(x, y) + self.h(z)
        sx, sy = self.dgd(x, y)
        sz = self.dhd(z)
        return s, sx * dx + sy * dy + sz * dz


class Aspheric(Surfaces):
    """
    非球面: https://en.wikipedia.org/wiki/Aspheric_lens.
    c：曲率，曲率半径的导数
    k：二次圆锥系数
    ai：非球面系数
    """

    def __init__(self, c, d, r, k=None, ai=None, is_square=False, device=torch.device('cpu')):
        Surfaces.__init__(self, r, d, is_square, device)
        self.c = c.to(device)
        if k is not None:
            self.k = k.to(device)
        else:
            self.k = torch.zeros_like(self.c)
        if ai is not None:
            self.ai = ai.to(device)
        else:
            self.ai = None

    # === Common methods
    def g(self, x, y):
        return self._g(x ** 2 + y ** 2)

    def dgd(self, x, y):
        dsdr2 = 2 * self._dgd(x ** 2 + y ** 2)
        return dsdr2 * x, dsdr2 * y

    def h(self, z):
        return -z

    def dhd(self, z):
        return -torch.ones_like(z)

    def surface(self, x, y):
        return self._g(x ** 2 + y ** 2)

    def reverse(self):
        self.c = -self.c
        if self.ai is not None:
            self.ai = -self.ai

    def surface_derivatives(self, x, y):
        dsdr2 = 2 * self._dgd(x ** 2 + y ** 2)
        return dsdr2 * x, dsdr2 * y, -torch.ones_like(x)

    def surface_and_derivatives_dot_D(self, t, dx, dy, dz, ox, oy, z, A, B, C):
        # pylint: disable=unused-argument
        # TODO: could be further optimized
        r2 = A * t ** 2 + B * t + C  # 加上t*d后x^2+y^2的值
        return self._g(r2) - z, self._dgd(r2) * (2 * A * t + B) - dz  # D与梯度的点乘积

    # === Private methods
    # 已知x,y坐标求z函数的准确值
    def _g(self, r2):
        tmp = r2 * self.c
        item = 1 - (1 + self.k) * tmp * self.c

        item = torch.clamp(item, min=1e-8)
        total_surface = tmp / (1 + torch.sqrt(item))
        higher_surface = 0
        if self.ai is not None:
            for i in np.flip(range(len(self.ai))):
                higher_surface = r2 * higher_surface + self.ai[i]
            higher_surface = higher_surface * r2 ** 2
        return total_surface + higher_surface

    # 求相应梯度
    def _dgd(self, r2):
        alpha_r2 = (1 + self.k) * self.c ** 2 * r2  # k为圆锥系数，c为曲率，r2为x^2+y^2
        item = 1 - alpha_r2
        item = torch.clamp(item, min=1e-8)
        tmp = torch.sqrt(item)  # TODO: potential NaN grad
        total_derivative = self.c * (1 + tmp - 0.5 * alpha_r2) / (tmp * (1 + tmp) ** 2)  # 基本的梯度

        higher_derivative = 0  # 高次项梯度
        if self.ai is not None:
            for i in np.flip(range(len(self.ai))):
                higher_derivative = r2 * higher_derivative + (i + 2) * self.ai[i]
        return total_derivative + higher_derivative * r2
