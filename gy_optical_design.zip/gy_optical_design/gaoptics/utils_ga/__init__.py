from gaoptics.utils_ga import parent_selection
from gaoptics.utils_ga import crossover
from gaoptics.utils_ga import mutation

__version__ = "1.0.1"