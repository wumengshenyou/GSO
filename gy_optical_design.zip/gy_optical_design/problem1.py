import numpy
import pickle
import time
import torch
import matplotlib.pyplot as plt
from torch.cuda.amp import autocast, GradScaler
import argparse
import gaoptics as ga
from gaoptics.simulation_func import *


def gener_lib(piece_num=1, aper_index=0, f_num=5.0, fov=20.0, dev=0, acc_fit=0.1, gener=10, b_size=2000):
    len_pop = ga.LensPopulation()
    len_pop.basics.piece_num = piece_num
    """
    初始化镜头，超参数配置
    """
    device = torch.device('cuda:' + str(dev))
    num_generations = gener
    len_pop.diff.sel_1_num = (num_generations // 3 * 2)
    len_pop.diff.op_n_num = 0
    len_pop.basics.val_flag = False
    mutation_percent_genes = [20, 20]
    len_pop.basics.acc_fit = acc_fit
    len_pop.basics.acc_range = 0.2
    len_pop.basics.z_object = -5000000  # 物距
    len_pop.basics.z_object_edof = [-5000000]  # 物距
    if len_pop.basics.val_flag:
        len_pop.diff.sel_1_num = 0
    len_pop.basics.aper_index = aper_index
    len_pop.constraint.distort = (-0.01, 0.01)  # 相对畸变

    len_pop.simulation.fov_hand_set = fov * (torch.linspace(1, 1, num_generations)).to(device)
    len_pop.basics.F_num_all = f_num * (torch.linspace(1, 1, num_generations)).to(device)
    len_pop.path.save_root = r'./init_structure/piece_{piece}_fov{fov}_fnum{fnum}_aper{x}.txt'.format(fov=fov
                                                                                                      , fnum=f_num,
                                                                                                      x=len_pop.basics.aper_index
                                                                                                      , piece=piece_num)
    # 光线追迹仿真参数配置
    len_pop.simulation.device = device
    len_pop.simulation.fov_num = 3
    len_pop.simulation.enp_num = 9
    len_pop.simulation.flag_auto_calc = True
    len_pop.simulation.wavelength = {
        "R": ([800.0], [1]),
        "G": ([600.0], [1]),
        "B": ([400.0], [1]),
    }

    # 光学系统基本参数配置
    len_pop.basics.acc_data = []
    len_pop.basics.acc_fit_all = []
    len_pop.basics.distort_all = []
    len_pop.basics.img_r = 3.905668  # 像面尺寸
    len_pop.constraint.effl = (len_pop.basics.img_r / math.tan(fov / 180 * math.pi) - 1, len_pop.basics.img_r / math.tan(fov / 180 * math.pi) + 1)
    len_pop.basics.MAX_R = 25  # 透镜最大半直径
    len_pop.basics.aper_R = (5, 25)
    len_pop.basics.conic_list = []
    len_pop.basics.aspheric_list = []
    len_pop.basics.aspheric_order = []

    # 物理约束边界定义
    len_pop.constraint.thi_glass_cen = (2, 10)  # 透镜中心厚度
    len_pop.constraint.thi_air_cen = (1, 15)  # 空气中心厚度
    len_pop.constraint.aper_d = len_pop.constraint.thi_air_cen
    len_pop.constraint.c = (-0.1, 0.1)  # 曲率（曲率半径倒数）的范围

    len_pop.constraint.k = None
    len_pop.constraint.aspheric = None
    len_pop.constraint.material_n = (1.51, 1.95)  # 折射率范围
    len_pop.constraint.material_V = (18.9, 81.6)  # 阿贝数范围
    len_pop.constraint.thi_glass_border = (2, 10)  # 透镜边缘厚度
    len_pop.constraint.thi_air_border = (1, 15)  # 空气边缘间距
    len_pop.constraint.bfl = (4, 15)  # 后工作距范围
    len_pop.constraint.z_sensor = (4, 120)  # 系统总长范围
    len_pop.constraint.defocus = len_pop.constraint.bfl
    len_pop.constraint.img = (-0.01, 0.01)

    # 特殊约束，无意义
    len_pop.constraint.edge_ray = 99999

    # 文件路径配置
    len_pop.path.demo_root = r'./init_structure/'
    len_pop.simulation.b_size = b_size
    len_pop.simulation.sol_per_pop = b_size
    sol_per_pop = len_pop.simulation.sol_per_pop
    init_population = len_pop.init_pop(sol_per_pop)

    num_genes = len_pop.basics.len_inputs
    len_pop.diff.weight_rms = torch.linspace(1, 1, num_generations).to(device)
    len_pop.diff.weight_ray_angle = (torch.linspace(0.01, 0.01, num_generations).to(device))

    len_pop.diff.weight_color = 0.25
    len_pop.diff.weight_fov = 0.0
    len_pop.diff.weight_constraint = 1
    len_pop.diff.weight_price = 0.0

    keep_elitism = int(sol_per_pop / ((3 * piece_num + 1) * 2))
    num_parents_mating = keep_elitism * 3
    init_range_low = 0
    init_range_high = 1
    random_mutation_min_val = 0,
    random_mutation_max_val = 1,

    parent_selection_type = "div"
    keep_parents = 1

    crossover_type = "uniform"

    mutation_type = "adaptive"
    save_best_solutions = False


    def fitness_func1(instance, sol, sol_idx, lens, draw=True):
        """
        仿真准备工作，相关参数初始化计算
        """
        dev = sol.device
        lens.re_init()
        t1 = time.time()  # 运行时间计算
        lens.set_basics(sol)
        # 自动计算一阶参数
        lens.calc_order1(flag_calc_exit=False, cal_time=False)
        fit_aberration, fit_img = lens.calc_fit_rms(weight_rms=lens.diff.weight_rms[lens.basics.gener_num]
                                                    , weight_ray_angle=len_pop.diff.weight_ray_angle[lens.basics.gener_num]
                                                    , M=lens.simulation.enp_num, weight_edge_ray=0.0,
                                                    weight_fov=lens.diff.weight_fov,
                                                    weight_color=lens.diff.weight_color, weight_defocus=0)
        fit_constraint, fit_price = lens.calc_fit_constraint(weight_bfl=0.05, weight_relative=0.1, weight_fov=0,
                                                             weight_z_sensor=0.01
                                                             , weight_board=0.1, weight_enp=1, weight_effl=0.1,
                                                             weight_aper_pos=0.1
                                                             , weight_price=1, weight_distort=1)
        fit_constraint = fit_constraint + fit_img
        fit_all = torch.ones(lens.simulation.b_size).to(lens.simulation.device) * 1e2
        fit_all[lens.basics.valid_idx] = 20 * (
                fit_aberration ** 2) + lens.diff.weight_constraint * fit_constraint + lens.diff.weight_price * fit_price

        fit_all[torch.isnan(fit_all)] = 1e2
        lens.basics.fit_all = fit_all

        if lens.basics.final_select_flag:
            final_divide_rate = 0.3
            acc_idx = torch.where(fit_all < lens.basics.acc_fit)[0]
            acc_data = sol[acc_idx]
            acc_fit_now = fit_all[acc_idx]

            fitness_sorted_idx = acc_fit_now.sort()[1]
            acc_fit_now_sorted = acc_fit_now.sort()[0]

            acc_idx_sorted = acc_idx[fitness_sorted_idx]
            acc_data_sorted = acc_data[fitness_sorted_idx]

            acc_idx2 = []
            for i in range(len(acc_idx_sorted)):
                now_idx = acc_idx_sorted[i]
                acc_flag = False
                if len(lens.basics.acc_data) == 0:
                    acc_flag = True
                else:
                    diff_fit = acc_fit_now_sorted[i] - torch.Tensor(lens.basics.acc_fit_all).to(dev)
                    diff = (acc_data_sorted[i] - torch.Tensor(lens.basics.acc_data).to(dev)).square().sum(
                        dim=-1).sqrt() / (sol.size(1) ** 0.5)
                    if diff.min(dim=0).values > final_divide_rate:
                        acc_flag = True
                    elif diff_fit[diff <= final_divide_rate].max() < -1e-3 and diff[
                        diff <= final_divide_rate].min() > final_divide_rate / 1000:
                        acc_flag = True
                if acc_flag:
                    lens.basics.acc_data.append(acc_data_sorted[i].tolist())
                    lens.basics.acc_fit_all.append(acc_fit_now_sorted[i])
                    acc_idx2.append(now_idx)
            acc_idx = torch.Tensor(acc_idx2).to(dev).long()
            lens.write_optics_data(acc_idx, save_path=len_pop.path.save_root)

            draw = True
            # 画光线追迹图
            if draw and len(acc_idx) > 0:
                sort_index = acc_idx
                # sort_index[0] = 0
                lens.draw_all(M=11, sort_index=sort_index)
        t5 = time.time()  # 运行时间计算
        return fit_all

    def fitness_func0(instance, sol, sol_idx, lens, draw=True):
        """
        仿真准备工作，相关参数初始化计算
        """
        t1 = time.time()  # 运行时间计算
        dev = sol.device
        lens.re_init()
        # 根据solution构建光学系统群，先编码成具有物理意义的量，再赋予光学系统
        lens.set_basics(sol)
        # 自动计算一阶参数
        lens.calc_order1(flag_calc_exit=False, cal_time=False)

        fit_aberration, fit_img = lens.calc_fit_aberration(weight_rms=lens.diff.weight_rms[lens.basics.gener_num]
                                                           , weight_ray_angle=len_pop.diff.weight_ray_angle[
                lens.basics.gener_num]
                                                           , M=lens.simulation.enp_num, weight_edge_ray=0.0,
                                                           weight_fov=lens.diff.weight_fov)
        # t3 = time.time()  # 运行时间计算
        # print('time_aberration:{time}'.format(time=t3 - t2))
        fit_constraint, fit_price = lens.calc_fit_constraint(weight_bfl=0.05, weight_relative=0.1, weight_fov=0,
                                                             weight_z_sensor=0.01
                                                             , weight_board=0.1, weight_enp=1, weight_effl=0.1,
                                                             weight_aper_pos=0.1
                                                             , weight_price=1, weight_distort=1)

        fit_constraint = fit_constraint + fit_img
        # t4 = time.time()  # 运行时间计算
        # print('time_con:{time}'.format(time=t4 - t3))
        fit_all = torch.ones(lens.simulation.b_size).to(lens.simulation.device) * 1e2
        fit_all[lens.basics.valid_idx] = 20 * (
                fit_aberration ** 2) + lens.diff.weight_constraint * fit_constraint + lens.diff.weight_price * fit_price

        fit_all[torch.isnan(fit_all)] = 1e3
        lens.basics.fit_all = fit_all
        t5 = time.time()  # 运行时间计算
        # print('time_all:{time}'.format(time=t5 - t1))
        return fit_all

    fitness_function1 = fitness_func1
    fitness_function0 = fitness_func0

    ga_instance = ga.GA(num_generations=num_generations,
                        num_parents_mating=num_parents_mating,
                        fitness_func1=fitness_function1,
                        fitness_func0=fitness_function0,
                        fitness_batch_size=len_pop.simulation.b_size,
                        sol_per_pop=sol_per_pop,
                        num_genes=num_genes,
                        init_range_low=init_range_low,
                        init_range_high=init_range_high,
                        parent_selection_type=parent_selection_type,
                        keep_parents=keep_parents,
                        keep_elitism=keep_elitism,
                        crossover_type=crossover_type,
                        crossover_probability=0.5,
                        mutation_type=mutation_type,
                        mutation_percent_genes=mutation_percent_genes,
                        random_mutation_min_val=random_mutation_min_val,
                        random_mutation_max_val=random_mutation_max_val,
                        initial_population=init_population,
                        len_pop=len_pop,
                        save_best_solutions=save_best_solutions)

    time_start = time.time()
    ga_instance.run()
    time_end = time.time()
    print('time_all:{time}'.format(time=time_end - time_start))


if __name__ == '__main__':
    torch.set_num_threads(8)
    parser = argparse.ArgumentParser()
    parser.add_argument('--acc_fit', type=float, default=0.2, help='0 1 2')
    parser.add_argument('--num_dev', type=int, default=0, help='0 1 2')
    parser.add_argument('--piece', type=int, default=8, help='0 1 2')
    parser.add_argument('--fov', type=float, default=27.5085, help='0 1 2')
    parser.add_argument('--fnum', type=float, default=3.0, help='0 1 2')
    parser.add_argument('--aper_idx', type=int, default=8, help='0 2 4 6')
    parser.add_argument('--gener_num', type=int, default=2, help='0 1 2')
    parser.add_argument('--b_size', type=int, default=2000, help='0 1 2')
    args = parser.parse_args()
    num_dev = args.num_dev
    fov = args.fov
    fnum = args.fnum
    piece_num = args.piece
    aper_idx = args.aper_idx

    gener_lib(fov=fov, f_num=fnum, aper_index=aper_idx, piece_num=piece_num, dev=num_dev,
              acc_fit=args.acc_fit, gener=args.gener_num, b_size=args.b_size)
